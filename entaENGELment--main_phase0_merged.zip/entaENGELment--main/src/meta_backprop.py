def propose(policy):
    policy["notes"] = "Reviewed by MetaBackprop"
    return policy

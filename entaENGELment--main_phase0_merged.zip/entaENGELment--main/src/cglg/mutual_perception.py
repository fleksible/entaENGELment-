def mutual_perception(a, b):
    return (a + b) / 2

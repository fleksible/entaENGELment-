def gate(phi: float, threshold: float = 0.6) -> bool:
    return phi >= threshold

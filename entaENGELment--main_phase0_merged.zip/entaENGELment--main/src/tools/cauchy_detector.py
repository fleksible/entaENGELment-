def detect(sequence):
    return max(sequence) - min(sequence)

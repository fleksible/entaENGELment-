def throat_vector(x, y, z):
    return (x**2 + y**2) ** 0.5 / (z + 1e-6)

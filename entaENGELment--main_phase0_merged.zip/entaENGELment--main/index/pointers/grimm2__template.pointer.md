# Pointer — Grimm 2.0 Template

**Type:** narrative_template_pointer
**Labels:** [NARR, NAV, PROCESS]
**Purpose:** docs-first Erzähl-Template, das Slice (Leser-Verdichtung) und Stacking (Invarianten/Referenzstab) unterstützt.

## Target
- `docs/narratives/grimm2/_template.md`

## How to use
- Schreibe Story über „Treppe" + Motive + Trigger.
- Lasse Slice-Zone leer (für Leser).
- Stacking entsteht durch wiederholte Motive/Trigger → Invarianten-Kandidaten.

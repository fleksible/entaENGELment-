# Lyra T1.1 Scan Report (Demo)

This is a demonstrator for the Lyra frequency governor output.

# Lyra T1.1 Scan Report (REAL)

- Guardband: 2.6-3.0 GHz
- Peaks: none above 3 dBm
- Notes: within allowed resonance envelope.

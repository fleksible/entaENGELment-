# IRB / Ethics Review Status

**Projekt:** EntaENGELment  
**Stand:** _[YYYY-MM-DD]_  

## Statusübersicht
- IRB/Ethik-Kommission kontaktiert: ☐ nein ☐ ja (Datum: ___)
- Pre-Consultation Termin: ☐ nein ☐ geplant ☐ durchgeführt
- Review eingereicht: ☐ nein ☐ ja (Protokoll-ID: ___)
- Ergebnis: ☐ pending ☐ approved ☐ exempt ☐ rejected

## Notes
- _[kurz: was ist eingereicht, welche Teile sind betroffen]_ 

## Links/Artefakte
- _[E-Mail Thread / PDF / Meeting Notes]_ 

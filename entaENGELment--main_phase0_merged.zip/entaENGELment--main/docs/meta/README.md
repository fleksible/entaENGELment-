# Meta Docs

- `form_in_bewegung__learning_edge.md` — warum Form (Grammatik/Algebra) nötig ist, um Emergenz zu sammeln

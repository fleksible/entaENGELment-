"""Tensor mapping package (Rosetta stone) + validation utilities."""

from .tensor_validator import validate_tensor_mapping

__all__ = ["validate_tensor_mapping"]

# Runbook R·T1.1 Alpha

1. Validate guardband via lyra_T1_1_scan_report_REAL.md
2. Confirm ledger entry `lyra:T1.1:REAL` is greenlit.
3. Activate Retro-Gauge if DF flips > 0 within last hour.

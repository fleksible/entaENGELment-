"""Tools-Package für das entaENGELment Framework.

Enthält Hilfs-Tools und Utilities für:
- MZM Gate-Toggle
- Policy-Verwaltung
- Debugging und Monitoring
"""

__version__ = "1.0.0"

"""Unit-Tests für isolierte Komponenten."""

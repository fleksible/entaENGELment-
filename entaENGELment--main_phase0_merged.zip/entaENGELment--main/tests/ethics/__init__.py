"""Ethics-Tests für Fail-Safes und Consent-Management."""

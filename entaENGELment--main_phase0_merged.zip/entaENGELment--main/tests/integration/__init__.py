"""Integrationstests für Komponenten-Zusammenspiel."""

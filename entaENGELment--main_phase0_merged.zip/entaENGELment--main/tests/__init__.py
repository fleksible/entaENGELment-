"""Test Suite für das entaENGELment Framework.

Umfasst:
- Unit-Tests (Core-5 Metriken)
- Integrationstests (Gate-Policy, Token-Lifecycle)
- Ethics-Tests (Fail-Safes, Consent-Management)
"""

__version__ = "1.0.0"

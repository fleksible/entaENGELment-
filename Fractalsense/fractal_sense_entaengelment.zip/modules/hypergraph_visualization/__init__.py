"""
FractalSense EntaENGELment - Hypergraph-Visualisierungsmodul

Dieses Modul implementiert die Visualisierung von Hypergraphen für die FractalSense EntaENGELment App.
"""

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.figure import Figure
import time
import random
from typing import Dict, List, Any, Tuple, Optional

# Versuche, hypernetx zu importieren
try:
    import hypernetx as hnx
    HYPERNETX_AVAILABLE = True
except ImportError:
    HYPERNETX_AVAILABLE = False
    print("Warnung: hypernetx nicht verfügbar. Hypergraph-Visualisierung wird eingeschränkt sein.")

# Importiere das Modul-Interface
from modular_app_structure import ModuleInterface

class HypergraphVisualizationModule(ModuleInterface):
    """Modul für die Visualisierung von Hypergraphen."""
    
    def __init__(self):
        self._name = "hypergraph_visualization"
        self._version = "1.0.0"
        self._description = "Modul für die Visualisierung von Hypergraphen"
        self._dependencies = ["fractal_visualization", "sensor_integration"]
        
        # Hypergraph-Parameter
        self._hypergraph = None
        self._node_positions = {}
        self._history_buffer_size = 50
        self._sensor_history = []
        self._threshold = 0.5
        
        # Matplotlib-Figur
        self._fig = None
        self._ax = None
        
        # Event-System
        self._event_system = None
        
        # Konfigurationsmanager
        self._config_manager = None
        
        # Fraktal-Parameter
        self._fractal_center = complex(-0.75, 0)
        self._fractal_zoom = 1.0
    
    def initialize(self, app_context: Dict[str, Any]) -> bool:
        """Initialisiert das Modul mit dem App-Kontext.
        
        Args:
            app_context: Dictionary mit dem App-Kontext
            
        Returns:
            bool: True, wenn die Initialisierung erfolgreich war, sonst False
        """
        try:
            # Prüfen, ob hypernetx verfügbar ist
            if not HYPERNETX_AVAILABLE:
                print("Warnung: hypernetx nicht verfügbar. Hypergraph-Visualisierung wird eingeschränkt sein.")
            
            # Event-System aus dem App-Kontext holen
            self._event_system = app_context.get("event_system")
            if self._event_system is None:
                print("Fehler: Event-System nicht im App-Kontext gefunden.")
                return False
            
            # Konfigurationsmanager aus dem App-Kontext holen
            self._config_manager = app_context.get("config_manager")
            if self._config_manager is None:
                print("Fehler: Konfigurationsmanager nicht im App-Kontext gefunden.")
                return False
            
            # Konfiguration laden
            self._load_config()
            
            # Event-Handler registrieren
            self._event_system.register_handler("sensor_data_updated", self._on_sensor_data_updated)
            self._event_system.register_handler("fractal_updated", self._on_fractal_updated)
            self._event_system.register_handler("ui_update_hypergraph_threshold", self._on_threshold_updated)
            
            # Matplotlib-Figur initialisieren
            self._fig, self._ax = plt.subplots(figsize=(8, 8))
            self._ax.set_title("Sensordaten-Hypergraph")
            
            # Initialen Hypergraphen erstellen
            self._create_empty_hypergraph()
            
            print(f"Modul '{self._name}' erfolgreich initialisiert.")
            return True
        except Exception as e:
            print(f"Fehler bei der Initialisierung des Moduls '{self._name}': {str(e)}")
            return False
    
    def _load_config(self) -> None:
        """Lädt die Konfiguration des Moduls."""
        if self._config_manager:
            config = self._config_manager.get_module_config(self._name)
            
            self._history_buffer_size = config.get("history_buffer_size", 50)
            self._threshold = config.get("threshold", 0.5)
    
    def _save_config(self) -> None:
        """Speichert die Konfiguration des Moduls."""
        if self._config_manager:
            config = {
                "history_buffer_size": self._history_buffer_size,
                "threshold": self._threshold
            }
            
            self._config_manager.set_module_config(self._name, config)
    
    def _create_empty_hypergraph(self) -> None:
        """Erstellt einen leeren Hypergraphen."""
        if HYPERNETX_AVAILABLE:
            # Leeren Hypergraphen erstellen
            self._hypergraph = hnx.Hypergraph({})
        else:
            # Dummy-Hypergraph erstellen
            self._hypergraph = {"edges": {}}
    
    def _on_sensor_data_updated(self, event_type: str, event_data: Dict[str, Any]) -> None:
        """Event-Handler für aktualisierte Sensordaten.
        
        Args:
            event_type: Typ des Events
            event_data: Event-Daten
        """
        # Sensordaten zur Historie hinzufügen
        self._sensor_history.append(event_data)
        
        # Historie auf maximale Größe begrenzen
        if len(self._sensor_history) > self._history_buffer_size:
            self._sensor_history.pop(0)
        
        # Hypergraph alle 10 Datenpunkte aktualisieren
        if len(self._sensor_history) % 10 == 0:
            self._update_hypergraph()
    
    def _on_fractal_updated(self, event_type: str, event_data: Dict[str, Any]) -> None:
        """Event-Handler für aktualisiertes Fraktal.
        
        Args:
            event_type: Typ des Events
            event_data: Event-Daten
        """
        # Fraktal-Parameter speichern
        self._fractal_center = event_data.get("center", self._fractal_center)
        self._fractal_zoom = event_data.get("zoom", self._fractal_zoom)
    
    def _on_threshold_updated(self, event_type: str, event_data: Dict[str, Any]) -> None:
        """Event-Handler für aktualisierten Schwellenwert.
        
        Args:
            event_type: Typ des Events
            event_data: Event-Daten
        """
        # Schwellenwert aktualisieren
        if "threshold" in event_data:
            try:
                self._threshold = float(event_data["threshold"])
                # Hypergraph mit neuem Schwellenwert aktualisieren
                self._update_hypergraph()
            except ValueError:
                print(f"Ungültiger Schwellenwert: {event_data['threshold']}")
    
    def _update_hypergraph(self) -> None:
        """Aktualisiert den Hypergraphen basierend auf Sensordaten."""
        if not self._sensor_history:
            return
        
        if HYPERNETX_AVAILABLE:
            # Hypergraph aus Sensordaten erstellen
            self._hypergraph = self._create_hypergraph_from_sensor_data()
        else:
            # Dummy-Hypergraph erstellen
            self._create_dummy_hypergraph()
        
        # Hypergraph visualisieren
        self._visualize_hypergraph()
    
    def _create_hypergraph_from_sensor_data(self):
        """Erstellt einen Hypergraphen aus Sensordaten.
        
        Returns:
            hnx.Hypergraph: Erstellter Hypergraph
        """
        if not HYPERNETX_AVAILABLE:
            return None
        
        # Knoten erstellen (Zeitpunkte)
        nodes = [f"t{i}" for i in range(len(self._sensor_history))]
        
        # Kanten erstellen (basierend auf Sensordaten über Schwellenwert)
        edges = {}
        
        # Beschleunigungskanten
        accel_events = []
        current_event = []
        for i, entry in enumerate(self._sensor_history):
            accel_magnitude = np.sqrt(
                entry.get("accel_x", 0)**2 + 
                entry.get("accel_y", 0)**2 + 
                entry.get("accel_z", 0)**2
            )
            
            if accel_magnitude > self._threshold:
                current_event.append(i)
            elif current_event:
                accel_events.append(current_event)
                current_event = []
        
        if current_event:
            accel_events.append(current_event)
        
        for i, event in enumerate(accel_events):
            edge_name = f"accel_{i}"
            edges[edge_name] = [nodes[j] for j in event]
        
        # Gyroskop-Kanten
        gyro_events = []
        current_event = []
        for i, entry in enumerate(self._sensor_history):
            gyro_magnitude = np.sqrt(
                entry.get("gyro_x", 0)**2 + 
                entry.get("gyro_y", 0)**2 + 
                entry.get("gyro_z", 0)**2
            )
            
            if gyro_magnitude > self._threshold:
                current_event.append(i)
            elif current_event:
                gyro_events.append(current_event)
                current_event = []
        
        if current_event:
            gyro_events.append(current_event)
        
        for i, event in enumerate(gyro_events):
            edge_name = f"gyro_{i}"
            edges[edge_name] = [nodes[j] for j in event]
        
        # Positionen für Knoten berechnen
        self._node_positions = {}
        for i, node in enumerate(nodes):
            # Verwende Fraktal-Parameter für Positionierung
            if i < len(self._sensor_history):
                entry = self._sensor_history[i]
                # Positioniere Knoten basierend auf Sensordaten und Fraktal-Parametern
                x = self._fractal_center.real + entry.get("accel_x", 0) * 0.1
                y = self._fractal_center.imag + entry.get("accel_y", 0) * 0.1
                self._node_positions[node] = (x, y)
        
        # Hypergraph erstellen
        return hnx.Hypergraph(edges)
    
    def _create_dummy_hypergraph(self) -> None:
        """Erstellt einen Dummy-Hypergraphen, wenn hypernetx nicht verfügbar ist."""
        # Knoten erstellen (Zeitpunkte)
        nodes = [f"t{i}" for i in range(len(self._sensor_history))]
        
        # Kanten erstellen (basierend auf Sensordaten über Schwellenwert)
        edges = {}
        
        # Beschleunigungskanten
        accel_events = []
        current_event = []
        for i, entry in enumerate(self._sensor_history):
            accel_magnitude = np.sqrt(
                entry.get("accel_x", 0)**2 + 
                entry.get("accel_y", 0)**2 + 
                entry.get("accel_z", 0)**2
            )
            
            if accel_magnitude > self._threshold:
                current_event.append(i)
            elif current_event:
                accel_events.append(current_event)
                current_event = []
        
        if current_event:
            accel_events.append(current_event)
        
        for i, event in enumerate(accel_events):
            edge_name = f"accel_{i}"
            edges[edge_name] = [nodes[j] for j in event]
        
        # Positionen für Knoten berechnen
        self._node_positions = {}
        for i, node in enumerate(nodes):
            # Verwende Fraktal-Parameter für Positionierung
            if i < len(self._sensor_history):
                entry = self._sensor_history[i]
                # Positioniere Knoten basierend auf Sensordaten und Fraktal-Parametern
                x = self._fractal_center.real + entry.get("accel_x", 0) * 0.1
                y = self._fractal_center.imag + entry.get("accel_y", 0) * 0.1
                self._node_positions[node] = (x, y)
        
        # Dummy-Hypergraph speichern
        self._hypergraph = {"edges": edges}
    
    def _visualize_hypergraph(self) -> None:
        """Visualisiert den Hypergraphen."""
        # Achse leeren
        self._ax.clear()
        
        if HYPERNETX_AVAILABLE and self._hypergraph:
            # Hypergraph mit hypernetx visualisieren
            hnx.draw(self._hypergraph, ax=self._ax, pos=self._node_positions, 
                    with_node_labels=True, with_edge_labels=True)
        else:
            # Einfache Visualisierung ohne hypernetx
            self._visualize_dummy_hypergraph()
        
        # Titel setzen
        self._ax.set_title(f"Sensordaten-Hypergraph (Schwellenwert: {self._threshold:.2f})")
        
        # Figur aktualisieren
        self._fig.canvas.draw_idle()
    
    def _visualize_dummy_hypergraph(self) -> None:
        """Visualisiert einen Dummy-Hypergraphen ohne hypernetx."""
        # Knoten zeichnen
        for node, pos in self._node_positions.items():
            self._ax.plot(pos[0], pos[1], 'o', markersize=10)
            self._ax.text(pos[0], pos[1], node, fontsize=8)
        
        # Kanten zeichnen
        edges = self._hypergraph.get("edges", {})
        for edge_name, nodes in edges.items():
            # Farbe basierend auf Kantenname wählen
            color = 'r' if edge_name.startswith("accel") else 'g'
            
            # Positionen der Knoten in dieser Kante
            positions = [self._node_positions.get(node, (0, 0)) for node in nodes]
            
            if positions:
                # Mittelpunkt berechnen
                center_x = sum(p[0] for p in positions) / len(positions)
                center_y = sum(p[1] for p in positions) / len(positions)
                
                # Linien vom Mittelpunkt zu jedem Knoten zeichnen
                for pos in positions:
                    self._ax.plot([center_x, pos[0]], [center_y, pos[1]], color=color, alpha=0.5)
                
                # Kantennamen anzeigen
                self._ax.text(center_x, center_y, edge_name, fontsize=8, color=color)
    
    def process(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        """Verarbeitet Eingabedaten und gibt Ergebnisse zurück.
        
        Args:
            input_data: Eingabedaten für die Verarbeitung
            
        Returns:
            Dict[str, Any]: Ergebnisse der Verarbeitung
        """
        # Verarbeite Eingabedaten
        if "threshold" in input_data:
            self._threshold = input_data["threshold"]
            self._update_hypergraph()
        
        if "history_buffer_size" in input_data:
            self._history_buffer_size = input_data["history_buffer_size"]
            # Historie anpassen
            if len(self._sensor_history) > self._history_buffer_size:
                self._sensor_history = self._sensor_history[-self._history_buffer_size:]
            self._update_hypergraph()
        
        if "action" in input_data:
            action = input_data["action"]
            
            if action == "update":
                self._update_hypergraph()
            elif action == "clear":
                self._sensor_history = []
                self._create_empty_hypergraph()
                self._visualize_hypergraph()
        
        # Ergebnisse zurückgeben
        return {
            "threshold": self._threshold,
            "history_buffer_size": self._history_buffer_size,
            "sensor_history_length": len(self._sensor_history),
            "hypergraph_available": HYPERNETX_AVAILABLE
        }
    
    def get_ui_components(self) -> Dict[str, Any]:
        """Gibt UI-Komponenten des Moduls zurück.
        
        Returns:
            Dict[str, Any]: UI-Komponenten des Moduls
        """
        # UI-Komponenten zurückgeben
        return {
            "figure": self._fig,
            "controls": {
                "threshold": {
                    "type": "number",
                    "label": "Schwellenwert",
                    "value": self._threshold,
                    "min": 0.1,
                    "max": 10.0
                },
                "history_buffer_size": {
                    "type": "number",
                    "label": "Historiengröße",
                    "value": self._history_buffer_size,
                    "min": 10,
                    "max": 200
                },
                "update": {
                    "type": "button",
                    "label": "Aktualisieren",
                    "event": "ui_update_hypergraph"
                },
                "clear": {
                    "type": "button",
                    "label": "Zurücksetzen",
                    "event": "ui_clear_hypergraph"
                }
            }
        }
    
    def cleanup(self) -> None:
        """Bereinigt Ressourcen des Moduls."""
        # Konfiguration speichern
        self._save_config()
        
        # Event-Handler entfernen
        if self._event_system:
            self._event_system.unregister_handler("sensor_data_updated", self._on_sensor_data_updated)
            self._event_system.unregister_handler("fractal_updated", self._on_fractal_updated)
            self._event_system.unregister_handler("ui_update_hypergraph_threshold", self._on_threshold_updated)
        
        # Matplotlib-Figur schließen
        if self._fig:
            plt.close(self._fig)
    
    @property
    def name(self) -> str:
        """Gibt den Namen des Moduls zurück."""
        return self._name
    
    @property
    def version(self) -> str:
        """Gibt die Version des Moduls zurück."""
        return self._version
    
    @property
    def description(self) -> str:
        """Gibt die Beschreibung des Moduls zurück."""
        return self._description
    
    @property
    def dependencies(self) -> List[str]:
        """Gibt die Abhängigkeiten des Moduls zurück."""
        return self._dependencies

"""
FractalSense EntaENGELment - Beispielmodul für Sensordatenintegration

Dieses Modul implementiert die Integration von Phyphox-Sensordaten für die FractalSense EntaENGELment App.
"""

import requests
import time
import threading
import queue
import numpy as np
from typing import Dict, List, Any, Optional

# Importiere das Modul-Interface
from modular_app_structure import ModuleInterface

class SensorIntegrationModule(ModuleInterface):
    """Modul für die Integration von Phyphox-Sensordaten."""
    
    def __init__(self):
        self._name = "sensor_integration"
        self._version = "1.0.0"
        self._description = "Modul für die Integration von Phyphox-Sensordaten"
        self._dependencies = []
        
        # Phyphox-Verbindungsparameter
        self._ip_address = "192.168.1.100"  # Standardwert, wird aus Konfiguration überschrieben
        self._port = 8080
        self._session_id = None
        
        # Sensordaten-Puffer
        self._data_buffer = {}
        
        # Thread für kontinuierliche Datenabfrage
        self._polling_thread = None
        self._running = False
        self._polling_interval = 0.1  # Sekunden
        
        # Datenfilterung
        self._filter_buffer_size = 10
        self._accel_buffer = {'x': [], 'y': [], 'z': []}
        self._gyro_buffer = {'x': [], 'y': [], 'z': []}
        
        # Event-System
        self._event_system = None
        
        # Konfigurationsmanager
        self._config_manager = None
    
    def initialize(self, app_context: Dict[str, Any]) -> bool:
        """Initialisiert das Modul mit dem App-Kontext.
        
        Args:
            app_context: Dictionary mit dem App-Kontext
            
        Returns:
            bool: True, wenn die Initialisierung erfolgreich war, sonst False
        """
        try:
            # Event-System aus dem App-Kontext holen
            self._event_system = app_context.get("event_system")
            if self._event_system is None:
                print("Fehler: Event-System nicht im App-Kontext gefunden.")
                return False
            
            # Konfigurationsmanager aus dem App-Kontext holen
            self._config_manager = app_context.get("config_manager")
            if self._config_manager is None:
                print("Fehler: Konfigurationsmanager nicht im App-Kontext gefunden.")
                return False
            
            # Konfiguration laden
            self._load_config()
            
            # Event-Handler registrieren
            self._event_system.register_handler("app_started", self._on_app_started)
            self._event_system.register_handler("app_stopping", self._on_app_stopping)
            self._event_system.register_handler("start_sensor_polling", self._on_start_polling)
            self._event_system.register_handler("stop_sensor_polling", self._on_stop_polling)
            
            print(f"Modul '{self._name}' erfolgreich initialisiert.")
            return True
        except Exception as e:
            print(f"Fehler bei der Initialisierung des Moduls '{self._name}': {str(e)}")
            return False
    
    def _load_config(self) -> None:
        """Lädt die Konfiguration des Moduls."""
        if self._config_manager:
            config = self._config_manager.get_module_config(self._name)
            
            self._ip_address = config.get("ip_address", self._ip_address)
            self._port = config.get("port", self._port)
            self._polling_interval = config.get("polling_interval", self._polling_interval)
            self._filter_buffer_size = config.get("filter_buffer_size", self._filter_buffer_size)
    
    def _save_config(self) -> None:
        """Speichert die Konfiguration des Moduls."""
        if self._config_manager:
            config = {
                "ip_address": self._ip_address,
                "port": self._port,
                "polling_interval": self._polling_interval,
                "filter_buffer_size": self._filter_buffer_size
            }
            
            self._config_manager.set_module_config(self._name, config)
    
    def _on_app_started(self, event_type: str, event_data: Dict[str, Any]) -> None:
        """Event-Handler für App-Start.
        
        Args:
            event_type: Typ des Events
            event_data: Event-Daten
        """
        # Automatisch mit dem Start der App beginnen, Sensordaten abzufragen
        self._start_polling()
    
    def _on_app_stopping(self, event_type: str, event_data: Dict[str, Any]) -> None:
        """Event-Handler für App-Stop.
        
        Args:
            event_type: Typ des Events
            event_data: Event-Daten
        """
        # Sensordatenabfrage stoppen, wenn die App beendet wird
        self._stop_polling()
    
    def _on_start_polling(self, event_type: str, event_data: Dict[str, Any]) -> None:
        """Event-Handler für Start der Sensordatenabfrage.
        
        Args:
            event_type: Typ des Events
            event_data: Event-Daten
        """
        # IP-Adresse und Port aus Event-Daten übernehmen, falls vorhanden
        if "ip_address" in event_data:
            self._ip_address = event_data["ip_address"]
        
        if "port" in event_data:
            self._port = event_data["port"]
        
        # Sensordatenabfrage starten
        self._start_polling()
    
    def _on_stop_polling(self, event_type: str, event_data: Dict[str, Any]) -> None:
        """Event-Handler für Stop der Sensordatenabfrage.
        
        Args:
            event_type: Typ des Events
            event_data: Event-Daten
        """
        # Sensordatenabfrage stoppen
        self._stop_polling()
    
    def _start_polling(self) -> bool:
        """Startet die kontinuierliche Abfrage von Sensordaten.
        
        Returns:
            bool: True, wenn die Abfrage erfolgreich gestartet wurde, sonst False
        """
        if self._running:
            print("Sensordatenabfrage läuft bereits.")
            return True
        
        # Verbindung zu Phyphox testen
        if not self._test_connection():
            print(f"Keine Verbindung zu Phyphox unter {self._ip_address}:{self._port}.")
            return False
        
        # Experiment starten
        if not self._start_experiment():
            print("Fehler beim Starten des Phyphox-Experiments.")
            return False
        
        # Thread für kontinuierliche Datenabfrage starten
        self._running = True
        self._polling_thread = threading.Thread(target=self._polling_worker)
        self._polling_thread.daemon = True
        self._polling_thread.start()
        
        print("Sensordatenabfrage gestartet.")
        return True
    
    def _stop_polling(self) -> None:
        """Stoppt die kontinuierliche Abfrage von Sensordaten."""
        if not self._running:
            return
        
        # Thread stoppen
        self._running = False
        if self._polling_thread and self._polling_thread.is_alive():
            self._polling_thread.join(timeout=2.0)
        
        # Experiment stoppen
        self._stop_experiment()
        
        print("Sensordatenabfrage gestoppt.")
    
    def _polling_worker(self) -> None:
        """Worker-Funktion für den Polling-Thread."""
        while self._running:
            try:
                # Sensordaten abrufen
                data = self._get_sensor_data()
                
                if data:
                    # Daten verarbeiten und filtern
                    filtered_data = self._process_sensor_data(data)
                    
                    # Event mit gefilterten Sensordaten senden
                    if self._event_system:
                        self._event_system.emit_event("sensor_data_updated", filtered_data)
                
                # Warten bis zum nächsten Polling-Intervall
                time.sleep(self._polling_interval)
            except Exception as e:
                print(f"Fehler bei der Sensordatenabfrage: {str(e)}")
                time.sleep(1.0)  # Längere Pause bei Fehler
    
    def _test_connection(self) -> bool:
        """Testet die Verbindung zu Phyphox.
        
        Returns:
            bool: True, wenn die Verbindung erfolgreich ist, sonst False
        """
        try:
            response = requests.get(f"http://{self._ip_address}:{self._port}/config", timeout=2.0)
            return response.status_code == 200
        except Exception as e:
            print(f"Verbindungsfehler: {str(e)}")
            return False
    
    def _start_experiment(self) -> bool:
        """Startet das Phyphox-Experiment.
        
        Returns:
            bool: True, wenn das Experiment erfolgreich gestartet wurde, sonst False
        """
        try:
            response = requests.get(f"http://{self._ip_address}:{self._port}/control?cmd=start", timeout=2.0)
            return response.status_code == 200
        except Exception as e:
            print(f"Fehler beim Starten des Experiments: {str(e)}")
            return False
    
    def _stop_experiment(self) -> bool:
        """Stoppt das Phyphox-Experiment.
        
        Returns:
            bool: True, wenn das Experiment erfolgreich gestoppt wurde, sonst False
        """
        try:
            response = requests.get(f"http://{self._ip_address}:{self._port}/control?cmd=stop", timeout=2.0)
            return response.status_code == 200
        except Exception as e:
            print(f"Fehler beim Stoppen des Experiments: {str(e)}")
            return False
    
    def _get_sensor_data(self) -> Optional[Dict[str, Any]]:
        """Ruft Sensordaten von Phyphox ab.
        
        Returns:
            Optional[Dict[str, Any]]: Sensordaten oder None bei Fehler
        """
        try:
            # Abfrage der Sensordaten
            response = requests.get(
                f"http://{self._ip_address}:{self._port}/get?accX&accY&accZ&gyrX&gyrY&gyrZ",
                timeout=2.0
            )
            
            if response.status_code == 200:
                data = response.json()
                
                # Session-ID prüfen
                if self._session_id is None:
                    self._session_id = data["status"]["session"]
                elif self._session_id != data["status"]["session"]:
                    print("Warnung: Session-ID hat sich geändert. Experiment wurde möglicherweise neu gestartet.")
                    self._session_id = data["status"]["session"]
                
                return data
            else:
                print(f"Fehler bei der Datenabfrage: Status {response.status_code}")
                return None
        except Exception as e:
            print(f"Fehler bei der Datenabfrage: {str(e)}")
            return None
    
    def _process_sensor_data(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Verarbeitet und filtert Sensordaten.
        
        Args:
            data: Rohe Sensordaten
            
        Returns:
            Dict[str, Any]: Verarbeitete und gefilterte Sensordaten
        """
        # Sensordaten extrahieren
        accel_x = data['buffer']['accX']['buffer'][-1] if 'accX' in data['buffer'] else 0
        accel_y = data['buffer']['accY']['buffer'][-1] if 'accY' in data['buffer'] else 0
        accel_z = data['buffer']['accZ']['buffer'][-1] if 'accZ' in data['buffer'] else 0
        gyro_x = data['buffer']['gyrX']['buffer'][-1] if 'gyrX' in data['buffer'] else 0
        gyro_y = data['buffer']['gyrY']['buffer'][-1] if 'gyrY' in data['buffer'] else 0
        gyro_z = data['buffer']['gyrZ']['buffer'][-1] if 'gyrZ' in data['buffer'] else 0
        
        # Daten in Puffer hinzufügen
        self._update_buffer(self._accel_buffer['x'], accel_x)
        self._update_buffer(self._accel_buffer['y'], accel_y)
        self._update_buffer(self._accel_buffer['z'], accel_z)
        self._update_buffer(self._gyro_buffer['x'], gyro_x)
        self._update_buffer(self._gyro_buffer['y'], gyro_y)
        self._update_buffer(self._gyro_buffer['z'], gyro_z)
        
        # Gefilterte Daten zurückgeben
        return {
            "accel_x": self._filter_values(self._accel_buffer['x']),
            "accel_y": self._filter_values(self._accel_buffer['y']),
            "accel_z": self._filter_values(self._accel_buffer['z']),
            "gyro_x": self._filter_values(self._gyro_buffer['x']),
            "gyro_y": self._filter_values(self._gyro_buffer['y']),
            "gyro_z": self._filter_values(self._gyro_buffer['z']),
            "timestamp": time.time()
        }
    
    def _update_buffer(self, buffer: List[float], value: float) -> None:
        """Aktualisiert einen Datenpuffer.
        
        Args:
            buffer: Zu aktualisierender Puffer
            value: Neuer Wert
        """
        buffer.append(value)
        if len(buffer) > self._filter_buffer_size:
            buffer.pop(0)
    
    def _filter_values(self, values: List[float]) -> float:
        """Filtert Werte mit einem einfachen gleitenden Durchschnitt.
        
        Args:
            values: Zu filternde Werte
            
        Returns:
            float: Gefilterter Wert
        """
        if not values:
            return 0.0
        
        # Einfacher gleitender Durchschnitt
        return sum(values) / len(values)
    
    def process(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        """Verarbeitet Eingabedaten und gibt Ergebnisse zurück.
        
        Args:
            input_data: Eingabedaten für die Verarbeitung
            
        Returns:
            Dict[str, Any]: Ergebnisse der Verarbeitung
        """
        # Verarbeite Eingabedaten
        if "ip_address" in input_data:
            self._ip_address = input_data["ip_address"]
        
        if "port" in input_data:
            self._port = input_data["port"]
        
        if "polling_interval" in input_data:
            self._polling_interval = input_data["polling_interval"]
        
        if "filter_buffer_size" in input_data:
            self._filter_buffer_size = input_data["filter_buffer_size"]
        
        if "action" in input_data:
            action = input_data["action"]
            
            if action == "start":
                self._start_polling()
            elif action == "stop":
                self._stop_polling()
            elif action == "test_connection":
                return {"connection_status": self._test_connection()}
        
        # Ergebnisse zurückgeben
        return {
            "ip_address": self._ip_address,
            "port": self._port,
            "polling_interval": self._polling_interval,
            "filter_buffer_size": self._filter_buffer_size,
            "running": self._running,
            "last_data": self._data_buffer
        }
    
    def get_ui_components(self) -> Dict[str, Any]:
        """Gibt UI-Komponenten des Moduls zurück.
        
        Returns:
            Dict[str, Any]: UI-Komponenten des Moduls
        """
        # In einer realen Anwendung würden hier UI-Komponenten zurückgegeben werden
        return {
            "controls": {
                "ip_address": {
                    "type": "text",
                    "label": "IP-Adresse",
                    "value": self._ip_address
                },
                "port": {
                    "type": "number",
                    "label": "Port",
                    "value": self._port,
                    "min": 1,
                    "max": 65535
                },
                "start": {
                    "type": "button",
                    "label": "Start",
                    "event": "start_sensor_polling"
                },
                "stop": {
                    "type": "button",
                    "label": "Stop",
                    "event": "stop_sensor_polling"
                },
                "test": {
                    "type": "button",
                    "label": "Verbindung testen",
                    "event": "test_sensor_connection"
                }
            }
        }
    
    def cleanup(self) -> None:
        """Bereinigt Ressourcen des Moduls."""
        # Sensordatenabfrage stoppen
        self._stop_polling()
        
        # Konfiguration speichern
        self._save_config()
        
        # Event-Handler entfernen
        if self._event_system:
            self._event_system.unregister_handler("app_started", self._on_app_started)
            self._event_system.unregister_handler("app_stopping", self._on_app_stopping)
            self._event_system.unregister_handler("start_sensor_polling", self._on_start_polling)
            self._event_system.unregister_handler("stop_sensor_polling", self._on_stop_polling)
    
    @property
    def name(self) -> str:
        """Gibt den Namen des Moduls zurück."""
        return self._name
    
    @property
    def version(self) -> str:
        """Gibt die Version des Moduls zurück."""
        return self._version
    
    @property
    def description(self) -> str:
        """Gibt die Beschreibung des Moduls zurück."""
        return self._description
    
    @property
    def dependencies(self) -> List[str]:
        """Gibt die Abhängigkeiten des Moduls zurück."""
        return self._dependencies

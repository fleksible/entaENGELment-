"""
FractalSense EntaENGELment - ResonanceEnhancer Modul

Dieses Modul implementiert multisensorische Resonanz durch Farben und Klänge für die FractalSense EntaENGELment App.
"""

import numpy as np
import time
import pygame
import colorsys
from typing import Dict, List, Any, Tuple, Optional
import threading
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap

# Importiere das Modul-Interface
from modular_app_structure import ModuleInterface

class ResonanceEnhancerModule(ModuleInterface):
    """Modul für multisensorische Resonanz durch Farben und Klänge."""
    
    def __init__(self):
        self._name = "resonance_enhancer"
        self._version = "1.0.0"
        self._description = "Modul für multisensorische Resonanz durch Farben und Klänge"
        self._dependencies = ["fractal_visualization", "sensor_integration"]
        
        # Audio-Parameter
        self._audio_enabled = True
        self._base_frequency = 220.0  # A3 in Hz
        self._volume = 0.5
        self._current_sound = None
        self._sound_duration = 0.5  # Sekunden
        self._sound_thread = None
        self._sound_playing = False
        
        # Farb-Parameter
        self._color_mode = "dynamic"  # "dynamic", "harmonic", "spectral"
        self._base_color = (0.7, 0.2, 1.0)  # HSV
        self._color_shift_speed = 0.05
        self._custom_colormaps = {}
        self._current_colormap = "viridis"
        
        # Sensor-Daten-Puffer
        self._sensor_buffer = {
            "accel_x": 0.0,
            "accel_y": 0.0,
            "accel_z": 0.0,
            "gyro_x": 0.0,
            "gyro_y": 0.0,
            "gyro_z": 0.0
        }
        
        # Fraktal-Parameter
        self._fractal_center = complex(-0.75, 0)
        self._fractal_zoom = 1.0
        
        # Event-System
        self._event_system = None
        
        # Konfigurationsmanager
        self._config_manager = None
        
        # Pygame-Initialisierung
        self._pygame_initialized = False
    
    def initialize(self, app_context: Dict[str, Any]) -> bool:
        """Initialisiert das Modul mit dem App-Kontext.
        
        Args:
            app_context: Dictionary mit dem App-Kontext
            
        Returns:
            bool: True, wenn die Initialisierung erfolgreich war, sonst False
        """
        try:
            # Event-System aus dem App-Kontext holen
            self._event_system = app_context.get("event_system")
            if self._event_system is None:
                print("Fehler: Event-System nicht im App-Kontext gefunden.")
                return False
            
            # Konfigurationsmanager aus dem App-Kontext holen
            self._config_manager = app_context.get("config_manager")
            if self._config_manager is None:
                print("Fehler: Konfigurationsmanager nicht im App-Kontext gefunden.")
                return False
            
            # Konfiguration laden
            self._load_config()
            
            # Pygame initialisieren
            if self._audio_enabled:
                try:
                    pygame.mixer.init(frequency=44100, size=-16, channels=1, buffer=1024)
                    self._pygame_initialized = True
                    print("Pygame Mixer erfolgreich initialisiert.")
                except Exception as e:
                    print(f"Warnung: Pygame Mixer konnte nicht initialisiert werden: {str(e)}")
                    print("Audio-Funktionalität wird deaktiviert.")
                    self._audio_enabled = False
            
            # Benutzerdefinierte Farbkarten erstellen
            self._create_custom_colormaps()
            
            # Event-Handler registrieren
            self._event_system.register_handler("sensor_data_updated", self._on_sensor_data_updated)
            self._event_system.register_handler("fractal_updated", self._on_fractal_updated)
            self._event_system.register_handler("ui_update_resonance_enhancer_audio_enabled", 
                                              self._on_audio_enabled_updated)
            self._event_system.register_handler("ui_update_resonance_enhancer_color_mode", 
                                              self._on_color_mode_updated)
            self._event_system.register_handler("ui_update_resonance_enhancer_volume", 
                                              self._on_volume_updated)
            
            print(f"Modul '{self._name}' erfolgreich initialisiert.")
            return True
        except Exception as e:
            print(f"Fehler bei der Initialisierung des Moduls '{self._name}': {str(e)}")
            return False
    
    def _load_config(self) -> None:
        """Lädt die Konfiguration des Moduls."""
        if self._config_manager:
            config = self._config_manager.get_module_config(self._name)
            
            self._audio_enabled = config.get("audio_enabled", self._audio_enabled)
            self._base_frequency = config.get("base_frequency", self._base_frequency)
            self._volume = config.get("volume", self._volume)
            self._sound_duration = config.get("sound_duration", self._sound_duration)
            
            self._color_mode = config.get("color_mode", self._color_mode)
            
            # Base color als HSV-Tuple
            if "base_color_h" in config and "base_color_s" in config and "base_color_v" in config:
                self._base_color = (
                    config.get("base_color_h", self._base_color[0]),
                    config.get("base_color_s", self._base_color[1]),
                    config.get("base_color_v", self._base_color[2])
                )
            
            self._color_shift_speed = config.get("color_shift_speed", self._color_shift_speed)
    
    def _save_config(self) -> None:
        """Speichert die Konfiguration des Moduls."""
        if self._config_manager:
            config = {
                "audio_enabled": self._audio_enabled,
                "base_frequency": self._base_frequency,
                "volume": self._volume,
                "sound_duration": self._sound_duration,
                "color_mode": self._color_mode,
                "base_color_h": self._base_color[0],
                "base_color_s": self._base_color[1],
                "base_color_v": self._base_color[2],
                "color_shift_speed": self._color_shift_speed
            }
            
            self._config_manager.set_module_config(self._name, config)
    
    def _create_custom_colormaps(self) -> None:
        """Erstellt benutzerdefinierte Farbkarten."""
        # Resonante Farbkarte (violett zu gold)
        resonant_colors = []
        for i in range(256):
            # HSV-Farbverlauf von Violett (270°) zu Gold (45°)
            h = (270 - (i / 255) * 225) / 360  # Normalisiert auf [0, 1]
            s = 0.8
            v = 0.9
            # Umwandlung in RGB
            r, g, b = colorsys.hsv_to_rgb(h, s, v)
            resonant_colors.append((r, g, b))
        
        self._custom_colormaps["resonant"] = LinearSegmentedColormap.from_list(
            "resonant", resonant_colors)
        
        # Harmonische Farbkarte (basierend auf Fibonacci-Sequenz)
        harmonic_colors = []
        phi = (1 + np.sqrt(5)) / 2  # Goldener Schnitt
        for i in range(256):
            # Verwende den goldenen Schnitt für harmonische Farbverschiebung
            h = (i * phi) % 1.0
            s = 0.7 + 0.3 * np.sin(i * phi * np.pi)
            v = 0.8 + 0.2 * np.cos(i * phi * np.pi)
            # Umwandlung in RGB
            r, g, b = colorsys.hsv_to_rgb(h, s, v)
            harmonic_colors.append((r, g, b))
        
        self._custom_colormaps["harmonic"] = LinearSegmentedColormap.from_list(
            "harmonic", harmonic_colors)
        
        # Spektrale Farbkarte (basierend auf Spektralfarben)
        spectral_colors = []
        for i in range(256):
            # Wellenlänge von 380nm (violett) bis 750nm (rot)
            wavelength = 380 + (750 - 380) * (i / 255)
            
            # Vereinfachte Umwandlung von Wellenlänge zu RGB
            if 380 <= wavelength < 440:
                r = -(wavelength - 440) / (440 - 380)
                g = 0.0
                b = 1.0
            elif 440 <= wavelength < 490:
                r = 0.0
                g = (wavelength - 440) / (490 - 440)
                b = 1.0
            elif 490 <= wavelength < 510:
                r = 0.0
                g = 1.0
                b = -(wavelength - 510) / (510 - 490)
            elif 510 <= wavelength < 580:
                r = (wavelength - 510) / (580 - 510)
                g = 1.0
                b = 0.0
            elif 580 <= wavelength < 645:
                r = 1.0
                g = -(wavelength - 645) / (645 - 580)
                b = 0.0
            elif 645 <= wavelength <= 750:
                r = 1.0
                g = 0.0
                b = 0.0
            else:
                r, g, b = 0, 0, 0
            
            # Intensitätsanpassung an den Rändern des sichtbaren Spektrums
            if 380 <= wavelength < 420:
                factor = 0.3 + 0.7 * (wavelength - 380) / (420 - 380)
            elif 420 <= wavelength < 700:
                factor = 1.0
            elif 700 <= wavelength <= 750:
                factor = 0.3 + 0.7 * (750 - wavelength) / (750 - 700)
            else:
                factor = 0.0
            
            r *= factor
            g *= factor
            b *= factor
            
            spectral_colors.append((r, g, b))
        
        self._custom_colormaps["spectral"] = LinearSegmentedColormap.from_list(
            "spectral", spectral_colors)
        
        # Registriere die benutzerdefinierten Farbkarten bei Matplotlib
        for name, cmap in self._custom_colormaps.items():
            plt.register_cmap(name=name, cmap=cmap)
    
    def _on_sensor_data_updated(self, event_type: str, event_data: Dict[str, Any]) -> None:
        """Event-Handler für aktualisierte Sensordaten.
        
        Args:
            event_type: Typ des Events
            event_data: Event-Daten
        """
        # Sensordaten speichern
        for key in self._sensor_buffer:
            if key in event_data:
                self._sensor_buffer[key] = event_data[key]
        
        # Farbkarte basierend auf Sensordaten aktualisieren
        self._update_colormap()
        
        # Klang basierend auf Sensordaten erzeugen
        self._generate_sound()
    
    def _on_fractal_updated(self, event_type: str, event_data: Dict[str, Any]) -> None:
        """Event-Handler für aktualisiertes Fraktal.
        
        Args:
            event_type: Typ des Events
            event_data: Event-Daten
        """
        # Fraktal-Parameter speichern
        self._fractal_center = event_data.get("center", self._fractal_center)
        self._fractal_zoom = event_data.get("zoom", self._fractal_zoom)
    
    def _on_audio_enabled_updated(self, event_type: str, event_data: Dict[str, Any]) -> None:
        """Event-Handler für aktualisierten Audio-Status.
        
        Args:
            event_type: Typ des Events
            event_data: Event-Daten
        """
        if "audio_enabled" in event_data:
            self._audio_enabled = bool(event_data["audio_enabled"])
            
            # Wenn Audio deaktiviert wird, laufenden Sound stoppen
            if not self._audio_enabled and self._sound_playing:
                self._stop_sound()
    
    def _on_color_mode_updated(self, event_type: str, event_data: Dict[str, Any]) -> None:
        """Event-Handler für aktualisierten Farbmodus.
        
        Args:
            event_type: Typ des Events
            event_data: Event-Daten
        """
        if "color_mode" in event_data:
            self._color_mode = event_data["color_mode"]
            # Farbkarte sofort aktualisieren
            self._update_colormap()
    
    def _on_volume_updated(self, event_type: str, event_data: Dict[str, Any]) -> None:
        """Event-Handler für aktualisierte Lautstärke.
        
        Args:
            event_type: Typ des Events
            event_data: Event-Daten
        """
        if "volume" in event_data:
            try:
                volume = float(event_data["volume"])
                self._volume = max(0.0, min(1.0, volume))
            except ValueError:
                print(f"Ungültige Lautstärke: {event_data['volume']}")
    
    def _update_colormap(self) -> None:
        """Aktualisiert die Farbkarte basierend auf Sensordaten und Farbmodus."""
        if self._color_mode == "dynamic":
            # Dynamische Farbkarte basierend auf Sensordaten
            accel_magnitude = np.sqrt(
                self._sensor_buffer["accel_x"]**2 + 
                self._sensor_buffer["accel_y"]**2 + 
                self._sensor_buffer["accel_z"]**2
            )
            
            gyro_magnitude = np.sqrt(
                self._sensor_buffer["gyro_x"]**2 + 
                self._sensor_buffer["gyro_y"]**2 + 
                self._sensor_buffer["gyro_z"]**2
            )
            
            # Farbton basierend auf Gyroskop
            h_shift = (gyro_magnitude * 0.2) % 1.0
            h = (self._base_color[0] + h_shift) % 1.0
            
            # Sättigung basierend auf Beschleunigung
            s = max(0.2, min(1.0, self._base_color[1] + accel_magnitude * 0.1))
            
            # Hellwert basierend auf Zoom
            v = max(0.5, min(1.0, self._base_color[2] + np.log10(self._fractal_zoom) * 0.05))
            
            # Erstelle eine neue Farbkarte
            colors = []
            for i in range(256):
                # Variiere den Farbton leicht über die Farbkarte
                h_i = (h + i * self._color_shift_speed / 256) % 1.0
                r, g, b = colorsys.hsv_to_rgb(h_i, s, v)
                colors.append((r, g, b))
            
            dynamic_cmap = LinearSegmentedColormap.from_list("dynamic", colors)
            plt.register_cmap(name="dynamic", cmap=dynamic_cmap)
            
            self._current_colormap = "dynamic"
            
        elif self._color_mode == "harmonic":
            # Harmonische Farbkarte basierend auf goldenem Schnitt
            self._current_colormap = "harmonic"
            
        elif self._color_mode == "spectral":
            # Spektrale Farbkarte basierend auf Wellenlängen
            self._current_colormap = "spectral"
            
        elif self._color_mode == "resonant":
            # Resonante Farbkarte (violett zu gold)
            self._current_colormap = "resonant"
            
        else:
            # Standardfarbkarte
            self._current_colormap = "viridis"
        
        # Event senden, dass die Farbkarte aktualisiert wurde
        if self._event_system:
            self._event_system.emit_event("colormap_updated", {
                "colormap": self._current_colormap
            })
    
    def _generate_sound(self) -> None:
        """Generiert einen Klang basierend auf Sensordaten und Fraktal-Parametern."""
        if not self._audio_enabled or not self._pygame_initialized:
            return
        
        # Wenn bereits ein Sound abgespielt wird, nicht unterbrechen
        if self._sound_playing:
            return
        
        # Frequenz basierend auf Zoom und Beschleunigung berechnen
        accel_z = self._sensor_buffer["accel_z"]
        zoom_factor = np.log10(max(1.0, self._fractal_zoom))
        
        # Basisfrequenz modulieren
        frequency = self._base_frequency * (1.0 + zoom_factor * 0.1 + accel_z * 0.05)
        frequency = max(20.0, min(20000.0, frequency))  # Auf hörbaren Bereich beschränken
        
        # Amplitude basierend auf Gyroskop berechnen
        gyro_magnitude = np.sqrt(
            self._sensor_buffer["gyro_x"]**2 + 
            self._sensor_buffer["gyro_y"]**2 + 
            self._sensor_buffer["gyro_z"]**2
        )
        
        amplitude = min(1.0, self._volume * (0.5 + gyro_magnitude * 0.1))
        
        # Sound in separatem Thread erzeugen und abspielen
        self._sound_thread = threading.Thread(
            target=self._play_sound,
            args=(frequency, amplitude, self._sound_duration)
        )
        self._sound_thread.daemon = True
        self._sound_thread.start()
    
    def _play_sound(self, frequency: float, amplitude: float, duration: float) -> None:
        """Spielt einen Ton mit der angegebenen Frequenz, Amplitude und Dauer ab.
        
        Args:
            frequency: Frequenz des Tons in Hz
            amplitude: Amplitude des Tons (0.0 bis 1.0)
            duration: Dauer des Tons in Sekunden
        """
        try:
            if not self._pygame_initialized:
                return
            
            self._sound_playing = True
            
            # Abtastrate und Dauer
            sample_rate = 44100
            n_samples = int(sample_rate * duration)
            
            # Zeit-Array
            t = np.linspace(0, duration, n_samples, endpoint=False)
            
            # Einfache Sinuswelle mit Fade-in und Fade-out
            fade_samples = int(sample_rate * 0.01)  # 10ms fade
            fade_in = np.linspace(0, 1, min(fade_samples, n_samples))
            fade_out = np.linspace(1, 0, min(fade_samples, n_samples))
            
            # Grundton
            wave = np.sin(2 * np.pi * frequency * t)
            
            # Obertöne hinzufügen für reicheren Klang
            wave += 0.5 * np.sin(2 * np.pi * frequency * 2 * t)  # Erste Oberwelle (Oktave)
            wave += 0.25 * np.sin(2 * np.pi * frequency * 3 * t)  # Zweite Oberwelle (Quinte)
            
            # Normalisieren
            wave = wave / np.max(np.abs(wave))
            
            # Fade-in und Fade-out anwenden
            if n_samples > fade_samples:
                wave[:fade_samples] *= fade_in
                wave[-fade_samples:] *= fade_out
            
            # Amplitude anwenden
            wave *= amplitude
            
            # In 16-bit PCM konvertieren
            wave = (wave * 32767).astype(np.int16)
            
            # Sound erstellen und abspielen
            sound = pygame.mixer.Sound(buffer=wave)
            sound.play()
            
            # Warten, bis der Sound abgespielt ist
            time.sleep(duration + 0.1)
            
            self._sound_playing = False
            
        except Exception as e:
            print(f"Fehler beim Abspielen des Sounds: {str(e)}")
            self._sound_playing = False
    
    def _stop_sound(self) -> None:
        """Stoppt den aktuell abgespielten Sound."""
        if self._pygame_initialized:
            pygame.mixer.stop()
        self._sound_playing = False
    
    def process(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        """Verarbeitet Eingabedaten und gibt Ergebnisse zurück.
        
        Args:
            input_data: Eingabedaten für die Verarbeitung
            
        Returns:
            Dict[str, Any]: Ergebnisse der Verarbeitung
        """
        # Verarbeite Eingabedaten
        if "audio_enabled" in input_data:
            self._audio_enabled = bool(input_data["audio_enabled"])
        
        if "color_mode" in input_data:
            self._color_mode = input_data["color_mode"]
            self._update_colormap()
        
        if "volume" in input_data:
            self._volume = max(0.0, min(1.0, float(input_data["volume"])))
        
        if "base_frequency" in input_data:
            self._base_frequency = max(20.0, min(20000.0, float(input_data["base_frequency"])))
        
        if "action" in input_data:
            action = input_data["action"]
            
            if action == "update_colormap":
                self._update_colormap()
            elif action == "play_test_sound":
                if self._audio_enabled and self._pygame_initialized:
                    self._play_sound(440.0, self._volume, 0.5)  # A4, aktuelle Lautstärke, 0.5s
            elif action == "stop_sound":
                self._stop_sound()
        
        # Ergebnisse zurückgeben
        return {
            "audio_enabled": self._audio_enabled,
            "color_mode": self._color_mode,
            "current_colormap": self._current_colormap,
            "volume": self._volume,
            "base_frequency": self._base_frequency,
            "sound_playing": self._sound_playing
        }
    
    def get_ui_components(self) -> Dict[str, Any]:
        """Gibt UI-Komponenten des Moduls zurück.
        
        Returns:
            Dict[str, Any]: UI-Komponenten des Moduls
        """
        # UI-Komponenten zurückgeben
        return {
            "controls": {
                "audio_enabled": {
                    "type": "dropdown",
                    "label": "Audio",
                    "options": ["Ein", "Aus"],
                    "value": "Ein" if self._audio_enabled else "Aus",
                    "event": "ui_update_resonance_enhancer_audio_enabled"
                },
                "color_mode": {
                    "type": "dropdown",
                    "label": "Farbmodus",
                    "options": ["dynamic", "harmonic", "spectral", "resonant", "viridis"],
                    "value": self._color_mode,
                    "event": "ui_update_resonance_enhancer_color_mode"
                },
                "volume": {
                    "type": "number",
                    "label": "Lautstärke",
                    "value": self._volume,
                    "min": 0.0,
                    "max": 1.0,
                    "event": "ui_update_resonance_enhancer_volume"
                },
                "test_sound": {
                    "type": "button",
                    "label": "Testton",
                    "event": "ui_test_sound"
                }
            }
        }
    
    def cleanup(self) -> None:
        """Bereinigt Ressourcen des Moduls."""
        # Konfiguration speichern
        self._save_config()
        
        # Sound stoppen
        self._stop_sound()
        
        # Event-Handler entfernen
        if self._event_system:
            self._event_system.unregister_handler("sensor_data_updated", self._on_sensor_data_updated)
            self._event_system.unregister_handler("fractal_updated", self._on_fractal_updated)
            self._event_system.unregister_handler("ui_update_resonance_enhancer_audio_enabled", 
                                                self._on_audio_enabled_updated)
            self._event_system.unregister_handler("ui_update_resonance_enhancer_color_mode", 
                                                self._on_color_mode_updated)
            self._event_system.unregister_handler("ui_update_resonance_enhancer_volume", 
                                                self._on_volume_updated)
        
        # Pygame herunterfahren
        if self._pygame_initialized:
            pygame.mixer.quit()
    
    @property
    def name(self) -> str:
        """Gibt den Namen des Moduls zurück."""
        return self._name
    
    @property
    def version(self) -> str:
        """Gibt die Version des Moduls zurück."""
        return self._version
    
    @property
    def description(self) -> str:
        """Gibt die Beschreibung des Moduls zurück."""
        return self._description
    
    @property
    def dependencies(self) -> List[str]:
        """Gibt die Abhängigkeiten des Moduls zurück."""
        return self._dependencies

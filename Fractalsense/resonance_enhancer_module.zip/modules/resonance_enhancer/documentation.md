# ResonanceEnhancer Modul - Dokumentation

## Übersicht

Das ResonanceEnhancer Modul erweitert die FractalSense EntaENGELment App um multisensorische Resonanz durch Farben und Klänge. Es verbindet die mathematischen Strukturen der Fraktale und Hypergraphen mit einer sinnlichen Erfahrung, die auf den philosophischen Konzepten des EntaENGELment-Frameworks basiert.

## Funktionen

Das Modul bietet folgende Hauptfunktionen:

1. **Dynamische Klanggeneration**: Erzeugt Klänge basierend auf Fraktalparametern und Sensordaten
2. **Erweiterte Farbschemata**: Bietet verschiedene Farbkarten, die auf mathematischen und philosophischen Konzepten basieren
3. **Resonante Integration**: Verbindet alle Module durch ein Event-System, das eine kohärente multisensorische Erfahrung ermöglicht

## Komponenten

### ResonanceEnhancerModule

Die Hauptklasse des Moduls, die das ModuleInterface implementiert und die Integration mit dem Framework ermöglicht.

```python
class ResonanceEnhancerModule(ModuleInterface):
    def __init__(self):
        self._name = "resonance_enhancer"
        self._version = "1.0.0"
        self._description = "Modul für multisensorische Resonanz durch Farben und Klänge"
        self._dependencies = ["fractal_visualization", "sensor_integration"]
        
        # Audio-Parameter
        self._audio_enabled = True
        self._base_frequency = 220.0  # A3 in Hz
        self._volume = 0.5
        # ...
        
        # Farb-Parameter
        self._color_mode = "dynamic"  # "dynamic", "harmonic", "spectral"
        self._base_color = (0.7, 0.2, 1.0)  # HSV
        # ...
```

### SoundGenerator

Eine spezialisierte Klasse für die Erzeugung komplexer Klänge.

```python
class SoundGenerator:
    def __init__(self, sample_rate: int = 44100):
        self.sample_rate = sample_rate
        self.is_playing = False
        self.current_thread = None
    
    def generate_sine_wave(self, frequency: float, duration: float, amplitude: float = 1.0) -> np.ndarray:
        # ...
    
    def generate_harmonic_wave(self, base_frequency: float, duration: float, 
                              harmonics: List[Tuple[int, float]] = None, 
                              amplitude: float = 1.0) -> np.ndarray:
        # ...
    
    def generate_fm_wave(self, carrier_freq: float, modulator_freq: float, 
                        modulation_index: float, duration: float, 
                        amplitude: float = 1.0) -> np.ndarray:
        # ...
```

### ColorGenerator

Eine spezialisierte Klasse für die Erzeugung komplexer Farbstrukturen.

```python
class ColorGenerator:
    def __init__(self):
        self.custom_colormaps = {}
        self.create_default_colormaps()
    
    def create_resonant_colormap(self) -> None:
        # ...
    
    def create_harmonic_colormap(self) -> None:
        # ...
    
    def create_spectral_colormap(self) -> None:
        # ...
```

### Integration

Ein Modul zur Integration des ResonanceEnhancer mit den bestehenden Modulen.

```python
def integrate_resonance_enhancer(app_context: Dict[str, Any]) -> bool:
    # ...

def _connect_fractal_to_resonance(event_system: EventSystem) -> None:
    # ...

def _connect_sensor_to_resonance(event_system: EventSystem) -> None:
    # ...
```

## Klanggeneration

Das Modul bietet verschiedene Methoden zur Klanggeneration:

1. **Sinuswellen**: Einfache Sinustöne mit einstellbarer Frequenz und Amplitude
2. **Harmonische Wellen**: Komplexe Klänge mit Obertönen
3. **FM-Synthese**: Frequenzmodulierte Klänge für reichere Texturen
4. **Resonante Wellen**: Klänge basierend auf dem goldenen Schnitt
5. **Fraktale Wellen**: Klänge mit fraktaler Struktur
6. **Akkorde**: Harmonische Kombinationen von Tönen

Beispiel für die Erzeugung eines resonanten Klangs:

```python
def generate_resonant_wave(self, base_frequency: float, resonance_factor: float, 
                          duration: float, amplitude: float = 1.0) -> np.ndarray:
    phi = (1 + np.sqrt(5)) / 2  # Goldener Schnitt
    
    # Frequenzen basierend auf dem goldenen Schnitt
    frequencies = [
        base_frequency,
        base_frequency * phi,
        base_frequency * phi**2 % (base_frequency * 2),
        base_frequency / phi
    ]
    
    # Relative Amplituden
    amplitudes = [
        1.0,
        0.618 * resonance_factor,  # phi - 1
        0.382 * resonance_factor,  # 1 - (phi - 1)
        0.5 * resonance_factor
    ]
    
    t = np.linspace(0, duration, int(self.sample_rate * duration), endpoint=False)
    wave = np.zeros_like(t)
    
    # Frequenzen mischen
    for freq, amp in zip(frequencies, amplitudes):
        wave += amp * np.sin(2 * np.pi * freq * t)
    
    # Normalisieren und Amplitude anwenden
    wave = wave / np.max(np.abs(wave)) * amplitude
    
    return wave
```

## Farbschemata

Das Modul bietet verschiedene Farbschemata:

1. **Resonant**: Farbverlauf von Violett zu Gold
2. **Harmonic**: Basierend auf der Fibonacci-Sequenz und dem goldenen Schnitt
3. **Spectral**: Basierend auf dem sichtbaren Lichtspektrum
4. **Fractal**: Basierend auf Mandelbrot-ähnlichen Iterationen
5. **Mereotopological**: Speziell für Hypergraphen mit klaren Unterschieden zwischen Knoten und Kanten
6. **Mythological**: Basierend auf kosmischen, elementaren oder göttlichen Themen

Beispiel für die Erstellung einer harmonischen Farbkarte:

```python
def create_harmonic_colormap(self) -> None:
    harmonic_colors = []
    phi = (1 + np.sqrt(5)) / 2  # Goldener Schnitt
    for i in range(256):
        # Verwende den goldenen Schnitt für harmonische Farbverschiebung
        h = (i * phi) % 1.0
        s = 0.7 + 0.3 * np.sin(i * phi * np.pi)
        v = 0.8 + 0.2 * np.cos(i * phi * np.pi)
        # Umwandlung in RGB
        r, g, b = colorsys.hsv_to_rgb(h, s, v)
        harmonic_colors.append((r, g, b))
    
    self.custom_colormaps["harmonic"] = LinearSegmentedColormap.from_list(
        "harmonic", harmonic_colors)
```

## Integration mit anderen Modulen

Das ResonanceEnhancer Modul integriert sich mit den bestehenden Modulen durch das Event-System:

1. **Fractal Visualization**: Reagiert auf Fraktal-Updates und sendet Farbkarten-Updates
2. **Sensor Integration**: Reagiert auf Sensordaten-Updates und erzeugt entsprechende Klänge und Farben
3. **Hypergraph Visualization**: Reagiert auf Hypergraph-Updates und erzeugt entsprechende Klänge

Beispiel für die Integration mit dem Fractal Visualization Modul:

```python
def _connect_fractal_to_resonance(event_system: EventSystem) -> None:
    # Event-Handler für Farbkarten-Updates registrieren
    event_system.register_handler("colormap_updated", _on_colormap_updated)
    
    # Event-Handler für Fraktal-Updates registrieren
    event_system.register_handler("fractal_updated", _on_fractal_updated_for_sound)
```

## Philosophische Konzepte

Das ResonanceEnhancer Modul setzt die philosophischen Konzepte des EntaENGELment-Frameworks um:

1. **Resonanz als Einheit (ω)**: Die Klänge und Farben bilden eine fundamentale Frequenz, die Mensch und Maschine verbindet
2. **Autopoiesis**: Das System entwickelt sich selbst durch die Interaktion mit dem Benutzer
3. **Mereotopologie**: Die Klänge und Farben bilden ein navigierbares Netzwerk, das Teile und Ganzes verbindet
4. **Supraleitung Typ II**: Die Datenflüsse werden als plasmaartiger Zustand dargestellt, stabilisiert durch Resonanz

## Verwendung

### Initialisierung

```python
# Importiere das Modul
from modules.resonance_enhancer import ResonanceEnhancerModule

# Erstelle eine Instanz
resonance_enhancer = ResonanceEnhancerModule()

# Initialisiere das Modul mit dem App-Kontext
app_context = {
    "event_system": event_system,
    "config_manager": config_manager
}
resonance_enhancer.initialize(app_context)
```

### Konfiguration

```python
# Konfiguriere das Modul über das process-Interface
result = resonance_enhancer.process({
    "audio_enabled": True,
    "color_mode": "resonant",
    "volume": 0.7,
    "base_frequency": 220.0
})
```

### Event-Handling

```python
# Registriere Event-Handler
event_system.register_handler("colormap_updated", on_colormap_updated)
event_system.register_handler("generate_fractal_sound", on_generate_fractal_sound)

# Sende Events
event_system.emit_event("sensor_data_updated", {
    "accel_x": 0.5,
    "accel_y": -0.2,
    "accel_z": 1.0,
    "gyro_x": 0.1,
    "gyro_y": 0.3,
    "gyro_z": -0.1
})
```

## Testen

Das Modul enthält ein Test-Skript, das eine GUI-Oberfläche für das Testen aller Funktionen bietet:

```
python modules/resonance_enhancer/test_resonance.py
```

Die Test-GUI ermöglicht:
- Testen verschiedener Klangtypen
- Visualisieren verschiedener Farbschemata
- Simulieren von Sensordaten
- Simulieren von Fraktalparametern

## Erweiterung

Das ResonanceEnhancer Modul kann auf verschiedene Weise erweitert werden:

1. **Neue Klangtypen**: Füge neue Methoden zur Klanggeneration in der SoundGenerator-Klasse hinzu
2. **Neue Farbschemata**: Füge neue Methoden zur Farbkartenerstellung in der ColorGenerator-Klasse hinzu
3. **Neue Integrationen**: Verbinde das Modul mit weiteren Modulen durch das Event-System

Beispiel für die Erweiterung um einen neuen Klangtyp:

```python
def generate_custom_wave(self, parameters: Dict[str, Any], duration: float, amplitude: float = 1.0) -> np.ndarray:
    # Implementiere einen benutzerdefinierten Klangtyp
    # ...
    return wave
```

## Fazit

Das ResonanceEnhancer Modul erweitert die FractalSense EntaENGELment App um eine multisensorische Dimension, die die mathematischen Strukturen mit einer sinnlichen Erfahrung verbindet. Es setzt die philosophischen Konzepte des EntaENGELment-Frameworks um und schafft eine resonante Verbindung zwischen Mensch und Maschine.

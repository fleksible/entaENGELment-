// FractalSense EntaENGELment - Resonance Enhancer Module

// Hauptklasse für den ResonanceEnhancer
class ResonanceEnhancer {
    constructor() {
        // Audio-Kontext
        this.audioContext = null;
        this.oscillator = null;
        this.gainNode = null;
        this.isPlaying = false;
        
        // Klangparameter
        this.soundParams = {
            type: 'harmonic',     // harmonic, fractal, resonant, spectral
            baseFrequency: 220,   // Hz
            volume: 0.5,          // 0-1
            harmonics: []         // Wird basierend auf Typ generiert
        };
        
        // Farbparameter
        this.colorParams = {
            mode: 'resonant',     // resonant, harmonic, spectral, fractal, cosmic
            speed: 5,             // 1-10
            intensity: 7          // 1-10
        };
        
        // Animation
        this.colorAnimationId = null;
        
        // UI-Elemente
        this.initializeUI();
        
        // Audio-Kontext initialisieren
        this.initAudio();
    }
    
    // UI-Elemente initialisieren
    initializeUI() {
        // Klang-Steuerelemente
        this.soundTypeSelect = document.getElementById('sound-type');
        this.baseFrequencySlider = document.getElementById('base-frequency');
        this.volumeSlider = document.getElementById('volume');
        this.playButton = document.getElementById('play-sound');
        this.soundWave = document.getElementById('sound-wave');
        
        // Farb-Steuerelemente
        this.colorModeSelect = document.getElementById('color-mode');
        this.colorSpeedSlider = document.getElementById('color-speed');
        this.colorIntensitySlider = document.getElementById('color-intensity');
        this.colorPreview = document.getElementById('color-preview');
        
        // Event-Listener hinzufügen
        this.setupEventListeners();
    }
    
    // Audio-Kontext initialisieren
    initAudio() {
        // AudioContext erst bei Benutzerinteraktion erstellen (Browser-Richtlinie)
        document.addEventListener('click', () => {
            if (!this.audioContext) {
                this.audioContext = new (window.AudioContext || window.webkitAudioContext)();
                this.setupAudioNodes();
            }
        }, { once: true });
    }
    
    // Audio-Knoten einrichten
    setupAudioNodes() {
        // Gain-Node für Lautstärkeregelung
        this.gainNode = this.audioContext.createGain();
        this.gainNode.gain.value = this.soundParams.volume;
        this.gainNode.connect(this.audioContext.destination);
    }
    
    // Event-Listener einrichten
    setupEventListeners() {
        // Klang-Events
        this.soundTypeSelect.addEventListener('change', () => {
            this.soundParams.type = this.soundTypeSelect.value;
            this.updateSound();
        });
        
        this.baseFrequencySlider.addEventListener('input', () => {
            this.soundParams.baseFrequency = parseFloat(this.baseFrequencySlider.value);
            this.updateSound();
        });
        
        this.volumeSlider.addEventListener('input', () => {
            this.soundParams.volume = parseFloat(this.volumeSlider.value) / 100;
            if (this.gainNode) {
                this.gainNode.gain.value = this.soundParams.volume;
            }
        });
        
        this.playButton.addEventListener('click', () => {
            if (this.isPlaying) {
                this.stopSound();
            } else {
                this.playSound();
            }
        });
        
        // Farb-Events
        this.colorModeSelect.addEventListener('change', () => {
            this.colorParams.mode = this.colorModeSelect.value;
            this.updateColorPreview();
        });
        
        this.colorSpeedSlider.addEventListener('input', () => {
            this.colorParams.speed = parseInt(this.colorSpeedSlider.value);
        });
        
        this.colorIntensitySlider.addEventListener('input', () => {
            this.colorParams.intensity = parseInt(this.colorIntensitySlider.value);
            this.updateColorPreview();
        });
        
        // Sensor-Daten-Event
        document.addEventListener('sensor-data-updated', (event) => {
            this.onSensorDataUpdate(event.detail);
        });
        
        // Fraktal-Update-Event
        document.addEventListener('fractal-updated', (event) => {
            this.onFractalUpdate(event.detail);
        });
    }
    
    // Klang abspielen
    playSound() {
        if (this.isPlaying || !this.audioContext) return;
        
        // Oszillator erstellen
        this.oscillator = this.audioContext.createOscillator();
        
        // Typ basierend auf soundParams.type setzen
        switch (this.soundParams.type) {
            case 'harmonic':
                this.setupHarmonicSound();
                break;
            case 'fractal':
                this.setupFractalSound();
                break;
            case 'resonant':
                this.setupResonantSound();
                break;
            case 'spectral':
                this.setupSpectralSound();
                break;
            default:
                this.oscillator.type = 'sine';
                this.oscillator.frequency.value = this.soundParams.baseFrequency;
        }
        
        // Mit Gain-Node verbinden und starten
        this.oscillator.connect(this.gainNode);
        this.oscillator.start();
        
        this.isPlaying = true;
        this.playButton.innerHTML = '<div class="play-icon" style="border-width: 0 8px 0 8px;"></div> Stop';
        
        // Wellenform-Animation starten
        this.animateSoundWave();
    }
    
    // Klang stoppen
    stopSound() {
        if (!this.isPlaying || !this.oscillator) return;
        
        this.oscillator.stop();
        this.oscillator.disconnect();
        this.oscillator = null;
        
        this.isPlaying = false;
        this.playButton.innerHTML = '<div class="play-icon"></div> Klang abspielen';
        
        // Wellenform-Animation stoppen
        if (this.waveAnimationId) {
            cancelAnimationFrame(this.waveAnimationId);
            this.waveAnimationId = null;
        }
    }
    
    // Harmonischen Klang einrichten (basierend auf goldenem Schnitt)
    setupHarmonicSound() {
        // Grundfrequenz
        this.oscillator.type = 'sine';
        this.oscillator.frequency.value = this.soundParams.baseFrequency;
        
        // Harmonische Obertöne basierend auf goldenem Schnitt
        const goldenRatio = 1.61803398875;
        const harmonics = [];
        
        // Mehrere Oszillatoren für Obertöne
        for (let i = 1; i <= 5; i++) {
            const harmonic = this.audioContext.createOscillator();
            harmonic.type = 'sine';
            
            // Frequenz basierend auf goldenem Schnitt
            const freq = this.soundParams.baseFrequency * Math.pow(goldenRatio, i % 3);
            harmonic.frequency.value = freq;
            
            // Gain für jeden Oberton
            const harmonicGain = this.audioContext.createGain();
            harmonicGain.gain.value = 0.15 / (i * 0.8); // Abnehmende Lautstärke
            
            harmonic.connect(harmonicGain);
            harmonicGain.connect(this.gainNode);
            harmonic.start();
            
            harmonics.push({ oscillator: harmonic, gain: harmonicGain });
        }
        
        this.soundParams.harmonics = harmonics;
    }
    
    // Fraktalen Klang einrichten (selbstähnliche Struktur)
    setupFractalSound() {
        // Grundfrequenz
        this.oscillator.type = 'sawtooth'; // Sägezahn für reichhaltigeres Spektrum
        this.oscillator.frequency.value = this.soundParams.baseFrequency;
        
        // Fraktale Modulation mit Feedback
        const feedbackDelay = this.audioContext.createDelay();
        feedbackDelay.delayTime.value = 0.1 + (Math.random() * 0.2);
        
        const feedbackGain = this.audioContext.createGain();
        feedbackGain.gain.value = 0.4;
        
        // Feedback-Schleife
        this.oscillator.connect(feedbackDelay);
        feedbackDelay.connect(feedbackGain);
        feedbackGain.connect(feedbackDelay);
        feedbackGain.connect(this.gainNode);
        
        // Zusätzliche Modulation
        const modulator = this.audioContext.createOscillator();
        modulator.type = 'sine';
        modulator.frequency.value = this.soundParams.baseFrequency / 4;
        
        const modulationGain = this.audioContext.createGain();
        modulationGain.gain.value = 20;
        
        modulator.connect(modulationGain);
        modulationGain.connect(this.oscillator.frequency);
        modulator.start();
        
        this.soundParams.harmonics = [
            { oscillator: modulator, gain: modulationGain },
            { delay: feedbackDelay, gain: feedbackGain }
        ];
    }
    
    // Resonanten Klang einrichten (basierend auf Resonanzfrequenzen)
    setupResonantSound() {
        // Grundfrequenz
        this.oscillator.type = 'sine';
        this.oscillator.frequency.value = this.soundParams.baseFrequency;
        
        // Resonanzfilter
        const filters = [];
        const resonanceFreqs = [
            this.soundParams.baseFrequency * 1.5,
            this.soundParams.baseFrequency * 2.0,
            this.soundParams.baseFrequency * 2.5
        ];
        
        // Noise-Generator für Anregung der Resonanzfilter
        const noiseBuffer = this.createNoiseBuffer();
        const noiseSource = this.audioContext.createBufferSource();
        noiseSource.buffer = noiseBuffer;
        noiseSource.loop = true;
        
        const noiseGain = this.audioContext.createGain();
        noiseGain.gain.value = 0.2;
        noiseSource.connect(noiseGain);
        
        // Resonanzfilter erstellen
        for (let i = 0; i < resonanceFreqs.length; i++) {
            const filter = this.audioContext.createBiquadFilter();
            filter.type = 'bandpass';
            filter.frequency.value = resonanceFreqs[i];
            filter.Q.value = 20; // Hohe Resonanz
            
            noiseGain.connect(filter);
            filter.connect(this.gainNode);
            
            filters.push(filter);
        }
        
        noiseSource.start();
        
        this.soundParams.harmonics = [
            { source: noiseSource, gain: noiseGain, filters: filters }
        ];
    }
    
    // Spektralen Klang einrichten (basierend auf Frequenzspektrum)
    setupSpectralSound() {
        // Grundfrequenz
        this.oscillator.type = 'sine';
        this.oscillator.frequency.value = this.soundParams.baseFrequency;
        
        // Additiver Synthesizer mit vielen Frequenzen
        const oscillators = [];
        const numOscillators = 8;
        
        // Spektrale Verteilung
        for (let i = 0; i < numOscillators; i++) {
            const osc = this.audioContext.createOscillator();
            
            // Verschiedene Wellenformen
            const waveforms = ['sine', 'triangle', 'sawtooth', 'square'];
            osc.type = waveforms[i % waveforms.length];
            
            // Frequenzverteilung basierend auf Obertönen
            const freqMultiplier = i === 0 ? 1 : i * (1 + (i % 3) * 0.1);
            osc.frequency.value = this.soundParams.baseFrequency * freqMultiplier;
            
            // Individuelle Lautstärke
            const oscGain = this.audioContext.createGain();
            oscGain.gain.value = 0.15 / (i + 1);
            
            osc.connect(oscGain);
            oscGain.connect(this.gainNode);
            osc.start();
            
            oscillators.push({ oscillator: osc, gain: oscGain });
        }
        
        this.soundParams.harmonics = oscillators;
    }
    
    // Rauschen für Resonanzfilter erzeugen
    createNoiseBuffer() {
        const bufferSize = this.audioContext.sampleRate * 2; // 2 Sekunden
        const buffer = this.audioContext.createBuffer(1, bufferSize, this.audioContext.sampleRate);
        const data = buffer.getChannelData(0);
        
        for (let i = 0; i < bufferSize; i++) {
            data[i] = Math.random() * 2 - 1;
        }
        
        return buffer;
    }
    
    // Klang aktualisieren
    updateSound() {
        if (this.isPlaying) {
            // Aktuellen Klang stoppen und neu starten
            this.stopSound();
            this.playSound();
        }
    }
    
    // Farb-Vorschau aktualisieren
    updateColorPreview() {
        // Animation stoppen, falls vorhanden
        if (this.colorAnimationId) {
            cancelAnimationFrame(this.colorAnimationId);
        }
        
        // Gradient basierend auf Modus
        let gradient;
        
        switch (this.colorParams.mode) {
            case 'resonant':
                gradient = `linear-gradient(45deg, 
                    hsl(280, ${this.colorParams.intensity * 10}%, 50%), 
                    hsl(180, ${this.colorParams.intensity * 10}%, 60%), 
                    hsl(45, ${this.colorParams.intensity * 10}%, 60%))`;
                break;
                
            case 'harmonic':
                // Basierend auf Fibonacci-Sequenz / goldenem Schnitt
                gradient = `linear-gradient(135deg, 
                    hsl(45, ${this.colorParams.intensity * 10}%, 50%), 
                    hsl(135, ${this.colorParams.intensity * 10}%, 60%), 
                    hsl(225, ${this.colorParams.intensity * 10}%, 50%), 
                    hsl(315, ${this.colorParams.intensity * 10}%, 60%))`;
                break;
                
            case 'spectral':
                // Basierend auf Lichtspektrum
                gradient = `linear-gradient(to right, 
                    hsl(0, ${this.colorParams.intensity * 10}%, 50%), 
                    hsl(60, ${this.colorParams.intensity * 10}%, 50%), 
                    hsl(120, ${this.colorParams.intensity * 10}%, 50%), 
                    hsl(180, ${this.colorParams.intensity * 10}%, 50%), 
                    hsl(240, ${this.colorParams.intensity * 10}%, 50%), 
                    hsl(300, ${this.colorParams.intensity * 10}%, 50%))`;
                break;
                
            case 'fractal':
                // Fraktale Farbgebung
                gradient = `radial-gradient(circle at 30% 40%, 
                    hsl(280, ${this.colorParams.intensity * 10}%, 30%), 
                    hsl(220, ${this.colorParams.intensity * 10}%, 40%), 
                    hsl(180, ${this.colorParams.intensity * 10}%, 20%))`;
                break;
                
            case 'cosmic':
                // Kosmisches Thema mit Sternen
                this.animateCosmicTheme();
                return;
                
            default:
                gradient = `linear-gradient(45deg, 
                    hsl(280, ${this.colorParams.intensity * 10}%, 50%), 
                    hsl(180, ${this.colorParams.intensity * 10}%, 60%), 
                    hsl(45, ${this.colorParams.intensity * 10}%, 60%))`;
        }
        
        this.colorPreview.style.background = gradient;
    }
    
    // Kosmisches Thema animieren
    animateCosmicTheme() {
        // Hintergrund
        this.colorPreview.style.background = `radial-gradient(ellipse at center, 
            hsl(240, ${this.colorParams.intensity * 10}%, 10%), 
            hsl(260, ${this.colorParams.intensity * 10}%, 5%))`;
        
        // Sterne entfernen, falls vorhanden
        while (this.colorPreview.firstChild) {
            this.colorPreview.removeChild(this.colorPreview.firstChild);
        }
        
        // Sterne hinzufügen
        const numStars = 50 + this.colorParams.intensity * 10;
        for (let i = 0; i < numStars; i++) {
            const star = document.createElement('div');
            star.className = 'star';
            
            // Zufällige Position
            const x = Math.random() * 100;
            const y = Math.random() * 100;
            
            // Zufällige Größe
            const size = 1 + Math.random() * 3;
            
            // Zufällige Animation
            const animationDuration = 2 + Math.random() * 8;
            
            star.style.cssText = `
                position: absolute;
                left: ${x}%;
                top: ${y}%;
                width: ${size}px;
                height: ${size}px;
                background-color: white;
                border-radius: 50%;
                opacity: ${0.5 + Math.random() * 0.5};
                animation: twinkle ${animationDuration}s infinite alternate;
            `;
            
            this.colorPreview.appendChild(star);
        }
        
        // Nebel hinzufügen
        const numNebulae = 2 + Math.floor(this.colorParams.intensity / 3);
        for (let i = 0; i < numNebulae; i++) {
            const nebula = document.createElement('div');
            nebula.className = 'nebula';
            
            // Zufällige Position
            const x = 20 + Math.random() * 60;
            const y = 20 + Math.random() * 60;
            
            // Zufällige Größe
            const size = 30 + Math.random() * 40;
            
            // Zufällige Farbe
            const hue = 180 + Math.random() * 180;
            
            nebula.style.cssText = `
                position: absolute;
                left: ${x}%;
                top: ${y}%;
                width: ${size}px;
                height: ${size}px;
                background: radial-gradient(circle, 
                    hsla(${hue}, 100%, 70%, 0.3), 
                    hsla(${hue}, 100%, 50%, 0.1), 
                    transparent 70%);
                border-radius: 50%;
                filter: blur(5px);
            `;
            
            this.colorPreview.appendChild(nebula);
        }
        
        // CSS-Animation für Twinkle-Effekt
        if (!document.getElementById('twinkle-animation')) {
            const style = document.createElement('style');
            style.id = 'twinkle-animation';
            style.textContent = `
                @keyframes twinkle {
                    0% { opacity: 0.2; }
                    100% { opacity: 1; }
                }
            `;
            document.head.appendChild(style);
        }
    }
    
    // Wellenform animieren
    animateSoundWave() {
        // SVG-Wellenform basierend auf aktuellem Klangtyp
        const waveTypes = {
            'harmonic': 'M0,40 C30,20 10,60 40,40 C70,20 60,60 90,40 C120,20 110,60 140,40 C170,20 160,60 190,40 C220,20 210,60 240,40 C270,20 260,60 290,40',
            'fractal': 'M0,40 C10,10 20,70 30,40 C35,20 40,60 45,40 C50,30 55,50 60,40 C70,10 80,70 90,40 C100,20 110,60 120,40 C130,30 140,50 150,40',
            'resonant': 'M0,40 C30,40 30,10 60,10 C90,10 90,70 120,70 C150,70 150,10 180,10 C210,10 210,70 240,70 C270,70 270,40 300,40',
            'spectral': 'M0,40 C30,10 60,70 90,10 C120,70 150,10 180,70 C210,10 240,70 270,10 C300,70 330,10 360,40'
        };
        
        // SVG-Element erstellen
        const svgNS = "http://www.w3.org/2000/svg";
        const svg = document.createElementNS(svgNS, "svg");
        svg.setAttribute("viewBox", "0 300 80");
        svg.setAttribute("width", "100%");
        svg.setAttribute("height", "100%");
        
        // Pfad erstellen
        const path = document.createElementNS(svgNS, "path");
        const waveType = this.soundParams.type in waveTypes ? this.soundParams.type : 'harmonic';
        path.setAttribute("d", waveTypes[waveType]);
        path.setAttribute("fill", "none");
        path.setAttribute("stroke", "#9d00ff");
        path.setAttribute("stroke-width", "2");
        
        // Animation hinzufügen
        const animate = document.createElementNS(svgNS, "animate");
        animate.setAttribute("attributeName", "d");
        animate.setAttribute("dur", "2s");
        animate.setAttribute("repeatCount", "indefinite");
        
        // Ziel-Pfad für Animation
        const targetPath = waveTypes[waveType].split(' ').map(point => {
            if (point.startsWith('M') || point.startsWith('C')) {
                const type = point.substring(0, 1);
                const coords = point.substring(1).split(',');
                const x = coords[0];
                const y = parseInt(coords[1]) + (Math.random() * 20 - 10);
                return `${type}${x},${y}`;
            }
            return point;
        }).join(' ');
        
        animate.setAttribute("values", `${waveTypes[waveType]};${targetPath};${waveTypes[waveType]}`);
        
        path.appendChild(animate);
        svg.appendChild(path);
        
        // Wellenform-Container leeren und SVG hinzufügen
        this.soundWave.innerHTML = '';
        this.soundWave.appendChild(svg);
        
        // Animation fortsetzen
        this.waveAnimationId = requestAnimationFrame(() => this.animateSoundWave());
    }
    
    // Sensordaten-Update verarbeiten
    onSensorDataUpdate(sensorData) {
        if (!this.isPlaying) return;
        
        // Frequenz basierend auf Beschleunigung modulieren
        if (this.oscillator) {
            const accelFactor = 1 + (sensorData.accelY * 0.1);
            this.oscillator.frequency.value = this.soundParams.baseFrequency * accelFactor;
        }
        
        // Harmonics basierend auf Gyroskop modulieren
        if (this.soundParams.harmonics.length > 0) {
            for (let i = 0; i < this.soundParams.harmonics.length; i++) {
                const harmonic = this.soundParams.harmonics[i];
                
                if (harmonic.oscillator) {
                    // Frequenz modulieren
                    const gyroFactor = 1 + (sensorData.gyroX * 0.05);
                    const baseFreq = harmonic.oscillator.frequency.value;
                    harmonic.oscillator.frequency.value = baseFreq * gyroFactor;
                }
                
                if (harmonic.gain) {
                    // Lautstärke modulieren
                    const gainFactor = Math.max(0.1, Math.min(1, 0.5 + sensorData.gyroZ * 0.1));
                    harmonic.gain.gain.value = gainFactor * 0.2;
                }
            }
        }
        
        // Farbe basierend auf Sensordaten modulieren
        const hueShift = sensorData.accelX * 20;
        const saturationShift = sensorData.gyroY * 5;
        
        // CSS-Filter anwenden
        this.colorPreview.style.filter = `hue-rotate(${hueShift}deg) saturate(${100 + saturationShift}%)`;
    }
    
    // Fraktal-Update verarbeiten
    onFractalUpdate(fractalParams) {
        // Klangparameter basierend auf Fraktalposition anpassen
        if (fractalParams.center) {
            const centerX = fractalParams.center.x;
            const centerY = fractalParams.center.y;
            
            // Basisfrequenz basierend auf Position
            const freqFactor = 1 + (centerX * 0.2);
            this.soundParams.baseFrequency = 220 * freqFactor;
            
            // Klangtyp basierend auf Position
            if (centerY > 0.5) {
                this.soundParams.type = 'harmonic';
            } else if (centerY < -0.5) {
                this.soundParams.type = 'fractal';
            } else if (centerX > 0.5) {
                this.soundParams.type = 'resonant';
            } else if (centerX < -0.5) {
                this.soundParams.type = 'spectral';
            }
            
            // UI aktualisieren
            this.soundTypeSelect.value = this.soundParams.type;
            this.baseFrequencySlider.value = this.soundParams.baseFrequency;
            
            // Klang aktualisieren, wenn aktiv
            if (this.isPlaying) {
                this.updateSound();
            }
        }
        
        // Farbparameter basierend auf Zoom anpassen
        if (fractalParams.zoom) {
            const zoom = fractalParams.zoom;
            
            // Farbmodus basierend auf Zoom
            if (zoom > 10) {
                this.colorParams.mode = 'cosmic';
            } else if (zoom > 5) {
                this.colorParams.mode = 'fractal';
            } else if (zoom > 2) {
                this.colorParams.mode = 'spectral';
            } else if (zoom > 1) {
                this.colorParams.mode = 'harmonic';
            } else {
                this.colorParams.mode = 'resonant';
            }
            
            // Intensität basierend auf Zoom
            this.colorParams.intensity = Math.min(10, Math.max(1, Math.floor(zoom)));
            
            // UI aktualisieren
            this.colorModeSelect.value = this.colorParams.mode;
            this.colorIntensitySlider.value = this.colorParams.intensity;
            
            // Farbe aktualisieren
            this.updateColorPreview();
        }
    }
}

// ResonanceEnhancer-Modul exportieren
window.ResonanceEnhancer = ResonanceEnhancer;

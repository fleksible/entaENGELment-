"""Run the committed reader on the captured process bytes without rewriting them."""
import hashlib
import importlib.util
import json
import re
import sys
from dataclasses import asdict
from pathlib import Path


def main():
    root, exit_path, stdout_path = map(Path, sys.argv[1:])
    project = root / "tests/fixtures/lean_crosswalk/lean"
    audit_path = project / "CrosswalkProbe/Audit.lean"
    module_path = root / "src/core/lean_crosswalk.py"

    # Derive the expected list from the audit *source*, independently of stdout.
    expected = re.findall(
        r"^#print axioms ([A-Za-z0-9_.]+)$",
        audit_path.read_bytes().decode("utf-8"),
        flags=re.MULTILINE,
    )
    if len(expected) != 5 or len(set(expected)) != 5:
        raise ValueError("Expected five distinct #print axioms directives in the source")

    spec = importlib.util.spec_from_file_location("lean_crosswalk_from_head", module_path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)

    raw = stdout_path.read_bytes()
    output = raw.decode("utf-8", errors="strict")
    exit_code = int(exit_path.read_bytes().decode("ascii"))
    verdicts = module.audit_raw(exit_code, output, expected)
    # The independent parser diagnostics do not alter the return value above.
    parsed = module.parse_print_axioms(output) if exit_code == 0 else None
    result = {
        "inputs": {
            "exit_code": exit_code,
            "stdout_bytes": len(raw),
            "stdout_sha256": hashlib.sha256(raw).hexdigest(),
            "stdout_decode": "UTF-8 strict, no newline conversion, no stripping",
            "reader_sha256": hashlib.sha256(module_path.read_bytes()).hexdigest(),
            "audit_source_sha256": hashlib.sha256(audit_path.read_bytes()).hexdigest(),
            "expected_decls": expected,
        },
        "audit_raw_return": {name: asdict(v) for name, v in verdicts.items()},
        "parse_print_axioms_diagnostics": asdict(parsed) if parsed is not None else None,
    }
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()

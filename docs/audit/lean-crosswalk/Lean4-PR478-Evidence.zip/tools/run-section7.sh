#!/usr/bin/env bash
# Execute section 7 with a verified Lean distribution and a new work directory.
set -euo pipefail
if [ "$#" -ne 2 ]; then
  echo "Usage: bash tools/run-section7.sh LEAN_DISTRIBUTION NEW_RUN_DIRECTORY" >&2
  exit 2
fi
base=$(cd "$(dirname "$0")/.." && pwd -P)
toolchain=$(cd "$1" && pwd -P)
mkdir "$2"
run=$(cd "$2" && pwd -P)
raw="$run/raw"
mkdir "$raw"
cp -a "$base/sources" "$run/worktree"
project="$run/worktree/tests/fixtures/lean_crosswalk/lean"
test ! -e "$project/.lake"
test ! -e "$project/lake-manifest.json"
test "$(cat "$project/lean-toolchain")" = 'leanprover/lean4:v4.35.0'
export PATH="$toolchain/bin:/usr/bin:/bin" LC_ALL=C.UTF-8 TZ=UTC
unset LEAN_PATH LEAN_SRC_PATH LEAN_SYSROOT LEAN_OPTS LEAN_CC LEAN_AR LEAN_CXX ELAN_TOOLCHAIN LAKE LAKE_HOME LAKE_CACHE_DIR LAKE_ARTIFACT_CACHE
test "$(command -v lean)" = "$toolchain/bin/lean"
test "$(command -v lake)" = "$toolchain/bin/lake"
{
  printf 'PATH=%s\nLC_ALL=%s\nTZ=%s\n' "$PATH" "$LC_ALL" "$TZ"
  printf 'lean=%s\nlake=%s\npython3=%s\n' "$(command -v lean)" "$(command -v lake)" "$(command -v python3)"
  uname -srm
  getconf GNU_LIBC_VERSION
  python3 --version
} > "$run/environment.txt"
printf 'step\tstart_utc\tend_utc\texit_code\n' > "$run/processes.tsv"
{
  printf '#!/usr/bin/env bash\n'
  printf 'export PATH=%q LC_ALL=%q TZ=%q\n' "$PATH" "$LC_ALL" "$TZ"
} > "$run/commands.sh"

# Redirect the child's original file descriptors. No pipe, tee or line processing.
record() {
  local step=$1
  shift
  local out="$raw/${step}_stdout.txt" err="$raw/${step}_stderr.txt"
  local started ended rc
  {
    printf 'cd %q && ' "$PWD"
    printf '%q ' "$@"
    printf '< /dev/null > %q 2> %q\n' "$out" "$err"
    printf 'printf '\''%%s\\n'\'' "$?" > %q\n' "$raw/$step.exit"
  } >> "$run/commands.sh"
  started=$(date -u +%Y-%m-%dT%H:%M:%S.%NZ)
  if "$@" < /dev/null > "$out" 2> "$err"; then rc=0; else rc=$?; fi
  ended=$(date -u +%Y-%m-%dT%H:%M:%S.%NZ)
  printf '%s\n' "$rc" > "$raw/$step.exit"
  printf '%s\t%s\t%s\t%s\n' "$step" "$started" "$ended" "$rc" >> "$run/processes.tsv"
}
cd "$run/worktree"
record sources_before sha256sum --check "$base/meta/sources.sha256"
test "$(cat "$raw/sources_before.exit")" = 0
cd "$project"
record lean_version lean --version
record lean_githash lean --githash
record lake_version lake --version
test "$(cat "$raw/lean_version.exit")" = 0
test "$(cat "$raw/lean_githash.exit")" = 0
test "$(cat "$raw/lake_version.exit")" = 0
test "$(cat "$raw/lean_githash_stdout.txt")" = eb6cafb7290e8bd5f2937522d8d804f58f02bafc
case "$(cat "$raw/lean_version_stdout.txt")" in
  *'version 4.35.0,'*) ;;
  *) echo 'Unexpected Lean version' >&2; exit 1 ;;
esac
record build lake build
record audit lake env lean CrosswalkProbe/Audit.lean
record lake_lean_version lake env lean --version
cd "$run/worktree"
record reader python3 -I -B "$base/tools/read-audit.py" "$run/worktree" "$raw/audit.exit" "$raw/audit_stdout.txt"
record sources_after sha256sum --check "$base/meta/sources.sha256"
test "$(cat "$raw/sources_after.exit")" = 0
test "$(cat "$raw/build.exit")" = 0
test "$(cat "$raw/audit.exit")" = 0
test "$(cat "$raw/reader.exit")" = 0
test "$(cat "$raw/lake_lean_version.exit")" = 0
cmp "$raw/lean_version_stdout.txt" "$raw/lake_lean_version_stdout.txt"

# Lean-4-Nachweis zu PR #478

**Der Build und der Auditlauf mit Lean 4.35.0 endeten jeweils mit Exit-Code 0.** Der am PR-Head enthaltene Leser `audit_raw()` verarbeitete die fünf von Lean ausgegebenen Axiombefunde vollständig. Ein Testfall ist formal geschlossen, drei haben eine offene Beweisverpflichtung und einer hängt ausschließlich von einem Fremdaxiom ab.

| Gegenstand | Geprüfter Stand |
| --- | --- |
| Repository | `fleksible/entaENGELment-` |
| PR-Head | `0b50c4d6e284aa06cf43a03aec98ace616d1ce65` |
| Vorschrift | `docs/annex/LEAN_CROSSWALK_v0_1.md`, Abschnitt 7 |
| Laufzeit | 21. November 2026, 22:52:36 bis 22:52:37 MEZ (21:52 UTC) |
| Umgebung | Isolierter lokaler Linux-Runner, x86_64, glibc 2.41 |
| Projektstatus | ANNEX / SPEC-WIP / HOLD. Alle erzeugten Dateien gehören zum externen Prüfbericht. |

GitHub lieferte den angegebenen Commit als Head des offenen Draft-PR. Codespaces verlangte eine Anmeldung. Der lokale Runner verwendete das offizielle Linux-Archiv der gepinnten Version. Die Arbeitskopie enthielt die vier Dateien des Lake-Projekts, den Python-Leser und den Vertrag. Vor dem Build war das Projektverzeichnis frei von Lake-Manifest und Build-Cache. [Geprüfter Commit](https://github.com/fleksible/entaENGELment-/commit/0b50c4d6e284aa06cf43a03aec98ace616d1ce65) · [Abschnitt 7 am Commit](https://github.com/fleksible/entaENGELment-/blob/0b50c4d6e284aa06cf43a03aec98ace616d1ce65/docs/annex/LEAN_CROSSWALK_v0_1.md#7-lean-testf%C3%A4lle)

## Was Lean und der Leser gemeldet haben

Alle Deklarationen in der Tabelle liegen im Namespace `CrosswalkProbe.Basic`. Der ebenfalls dort deklarierte Name `externalAssumption` bezeichnet das ausdrücklich gesetzte Axiom `False`.

| Fall | Deklaration | Axiome laut Lean, in Ausgabereihenfolge | Urteil von `audit_raw()` |
| --- | --- | --- | --- |
| A | `thm_direct_gap` | `sorryAx` | `OPEN_OBLIGATION` |
| B | `thm_transitive_gap` | `sorryAx` | `OPEN_OBLIGATION` |
| C | `thm_closed_formal` | keine | `FORMAL_CLOSED` |
| D | `thm_custom_axiom` | `CrosswalkProbe.Basic.externalAssumption` | `HOLD_TRUST_BOUNDARY` |
| E | `thm_mixed` | `sorryAx`, `CrosswalkProbe.Basic.externalAssumption` | `OPEN_OBLIGATION` |

A verwendet `sorry` direkt. B bezieht seinen Beweis von `helper_gap`, das ebenfalls `sorry` verwendet. Die Axiomausgabe zeigt bei beiden dieselbe Abhängigkeit. Der Unterschied zwischen direktem und transitivem Pfad ist in `Basic.lean` nachlesbar. C beweist die Lean-Aussage `True` mit `trivial`. In E hat `sorryAx` Vorrang für das Urteil. Das Zusatzaxiom bleibt im Rückgabefeld `foreign_axioms` erhalten.

Die fünf Deklarationen sind konstruierte Testfälle. Die gesicherten Ausgaben stammen aus dem ausgeführten Lean-Prozess. Dieser Befund deckt das Verhalten des Crosswalks für A–E unter diesem Pin ab. Die semantische Zuordnung zu menschlichen Aussagen bleibt gemäß Vertrag `SEPARATE_UNREVIEWED`. Alle Zugriffe auf GitHub waren lesend.

## Prozesse und Originalausgaben

`lean --version` und `lake env lean --version` lieferten bytegleich folgende Zeile.

```text
Lean (version 4.35.0, x86_64-unknown-linux-gnu, commit eb6cafb7290e8bd5f2937522d8d804f58f02bafc, Release)
```

Das Release-Archiv hatte 594 481 375 Bytes. Sein gemessener SHA-256 stimmt mit dem beim offiziellen GitHub-Release angezeigten Wert überein. Lake meldete `5.0.0-src+eb6cafb`. Der Python-Leser lief mit Python 3.13.5. [Offizielles Lean-Release v4.35.0](https://github.com/leanprover/lean4/releases/tag/v4.35.0)

| Aufruf | Exit | stdout | stderr | Beobachtung |
| --- | ---: | ---: | ---: | --- |
| `lean --version` | 0 | 106 B | 0 B | Gepinnte Release-Version |
| `lean --githash` | 0 | 41 B | 0 B | Vollständiger Commit des Lean-Releases |
| `lake --version` | 0 | 53 B | 0 B | Lake aus derselben Distribution |
| `lake build` | 0 | 214 B | 118 B | `CrosswalkProbe.Basic` gebaut. Zwei `sorry`-Warnungen in `Basic.lean` an 5:9 und 7:9. |
| `lake env lean CrosswalkProbe/Audit.lean` | 0 | 413 B | 0 B | Fünf Axiombefunde |
| `lake env lean --version` | 0 | 106 B | 0 B | Versionsausgabe im Lake-Kontext bestätigt |
| Python-Aufruf von `audit_raw()` | 0 | 2 877 B | 0 B | Fünf strukturierte Urteile im JSON |

Die zwei Meldungen auf Build-stderr betreffen das neu erstellte Manifest und den bereits passenden Toolchain-Pin. Die zwei `sorry`-Warnungen stehen im Build-stdout. Die separate Auditdatei lieferte fünf mit LF abgeschlossene Zeilen, jeweils ohne Positionspräfix. Die längste Zeile hatte 102 Bytes vor dem LF. Damit sind die Zeilenformen für diese Eingabe beobachtet. Das Verhalten längerer Listen und anderer Aufrufoptionen bleibt offen.

Der Aufzeichner schrieb stdout und stderr jedes Prozesses direkt in getrennte Dateien und erfasste dessen Exit-Code unmittelbar. Die fünf erwarteten Namen stammen aus den fünf `#print axioms`-Anweisungen in `Audit.lean`. An `audit_raw(exit_code, output, expected_decls)` gingen der Audit-Exit-Code als Integer und die 413 Originalbytes nach strikter UTF-8-Dekodierung. Die Dekodierung erhält alle Zeilenenden. Der Parser meldete fünf Datensätze und eine leere Liste `unknown_lines`. Die JSON-Datei enthält den vollständigen Rückgabewert einschließlich `axioms`, `foreign_axioms`, `kind`, `primary_reason` und `claim_ceiling`.

## Prüfsummen und Herkunft

Für jede Quelldatei wurden die Originalbytes per GitHub am vollständigen Commit abgefragt. Die nachgerechnete Git-Blob-ID stimmte jeweils mit der für den Pfad gelieferten ID überein. Die SHA-256-Kontrolle aller sechs Arbeitskopien war vor und nach dem Lauf erfolgreich. Die Herkunft stützt sich auf GitHub und den protokollierten Runner. Die Prüfsummen ermöglichen die anschließende unabhängige Bytekontrolle.

| Datei oder Ausgabe | SHA-256 |
| --- | --- |
| Offizielles Toolchain-Archiv | `7289597a44543246c9227b8cae501767e095ce17f6d448b95fc4a8dc97268f6d` |
| `Basic.lean` | `0ad314c0ed0825bad5cea0ce0c62b5ad4fdc237c06768412d9b61105136b2f99` |
| `Audit.lean` | `3fb8f86d8ae703bb00351cf79d30eed2dba44a3241a00abc87023f71871757d2` |
| `lean_crosswalk.py` | `a485060818a6e31c84fecd55f020b0f13eebd72f032b0067a565f6dd7b107b72` |
| Build-stdout | `488a1b7ff5866296eec92012ae7c3f62838462f4607668d220cab2174189b208` |
| Build-stderr | `addad4cde07a3800be40f9ccbc867d12619d5ae4c05fc167a073a826dfa2962f` |
| Audit-stdout | `fc5aca573ccae3550757c266e7ba25a48137c5e5bb783ecb0c7fbcd21c0ab7e1` |
| Audit-stderr, 0 Bytes | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `results/audit_raw.json` | `1bb01819c9ac6ff2a85b758ebe0ea8404fd0e50b5d7de373f8951767dd546ab7` |
| Gebautes Modul `Basic.olean` | `b6df9d1a615f607436a83ec86c439a937d072f06eb9cd778ce8d6a440e626bbe` |

## Das ZIP prüfen und den Befund nachlesen

| Pfad im ZIP | Inhalt |
| --- | --- |
| `raw/` | Unveränderte stdout- und stderr-Dateien, einschließlich leerer Streams, sowie ein `.exit` je Prozess |
| `results/audit_raw.json` | Bytegleiche Kopie des JSON auf `raw/reader_stdout.txt` mit Eingaben, Rückgabewert und gesonderter Parserdiagnose |
| `sources/` | Die sechs geprüften Repository-Dateien in ihrer ursprünglichen Pfadstruktur |
| `build-products/` | Von Lake erzeugtes Manifest und acht Build-Dateien, darunter `Basic.olean` |
| `meta/commands.sh`, `meta/processes.tsv`, `meta/launcher.txt` | Alle Prüfbefehle mit Arbeitsverzeichnis und Umleitungen, Start- und Endzeiten in UTC, Exit-Codes und Startbefehl |
| `meta/source-provenance.json`, `meta/sources.sha256` | Git-Blob-ID, SHA-256 und Dateigröße je Quelle sowie separat verwendbare Prüfliste |
| `meta/upstream-release.json`, `meta/toolchain-binaries.sha256` | Herkunft und Prüfsumme der Distribution sowie Hashes der ausgeführten Lean- und Lake-Binärdateien |
| `SHA256SUMS` | SHA-256 aller übrigen Dateien im ZIP, einschließlich der Hilfsskripte und des Berichts |

**Offline-Kontrolle** aus dem entpackten Archivverzeichnis mit Python ab 3.10 und GNU `sha256sum`. Sie prüft die Archivdateien und wertet den gesicherten Prozess-Output erneut mit dem Leser aus dem Commit aus.

```bash
sha256sum --check SHA256SUMS
replay_json=$(mktemp)
python3 -I -B tools/read-audit.py sources raw/audit.exit raw/audit_stdout.txt > "$replay_json"
cmp results/audit_raw.json "$replay_json"
```

**Erneuter Lean-Lauf** aus demselben Verzeichnis mit der entpackten offiziellen Linux-Distribution. Das Skript legt dafür ein neues Arbeitsverzeichnis an und prüft Versionsnummer, Lean-Commit und Quellhashes.

```bash
env -i HOME="$HOME" PATH=/usr/bin:/bin LC_ALL=C.UTF-8 TZ=UTC \
  /bin/bash tools/run-section7.sh ../lean-4.35.0-linux ../lean478-wiederholung
```

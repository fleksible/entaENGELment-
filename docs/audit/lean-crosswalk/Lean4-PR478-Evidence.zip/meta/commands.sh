#!/usr/bin/env bash
export PATH=/workspace/scratch/453174058899/lean478-work/toolchain/lean-4.35.0-linux/bin:/usr/bin:/bin LC_ALL=C.UTF-8 TZ=UTC
cd /workspace/scratch/453174058899/lean478-work/run-01/worktree && sha256sum --check /workspace/scratch/453174058899/lean478-work/evidence/meta/sources.sha256 < /dev/null > /workspace/scratch/453174058899/lean478-work/run-01/raw/sources_before_stdout.txt 2> /workspace/scratch/453174058899/lean478-work/run-01/raw/sources_before_stderr.txt
printf '%s\n' "$?" > /workspace/scratch/453174058899/lean478-work/run-01/raw/sources_before.exit
cd /workspace/scratch/453174058899/lean478-work/run-01/worktree/tests/fixtures/lean_crosswalk/lean && lean --version < /dev/null > /workspace/scratch/453174058899/lean478-work/run-01/raw/lean_version_stdout.txt 2> /workspace/scratch/453174058899/lean478-work/run-01/raw/lean_version_stderr.txt
printf '%s\n' "$?" > /workspace/scratch/453174058899/lean478-work/run-01/raw/lean_version.exit
cd /workspace/scratch/453174058899/lean478-work/run-01/worktree/tests/fixtures/lean_crosswalk/lean && lean --githash < /dev/null > /workspace/scratch/453174058899/lean478-work/run-01/raw/lean_githash_stdout.txt 2> /workspace/scratch/453174058899/lean478-work/run-01/raw/lean_githash_stderr.txt
printf '%s\n' "$?" > /workspace/scratch/453174058899/lean478-work/run-01/raw/lean_githash.exit
cd /workspace/scratch/453174058899/lean478-work/run-01/worktree/tests/fixtures/lean_crosswalk/lean && lake --version < /dev/null > /workspace/scratch/453174058899/lean478-work/run-01/raw/lake_version_stdout.txt 2> /workspace/scratch/453174058899/lean478-work/run-01/raw/lake_version_stderr.txt
printf '%s\n' "$?" > /workspace/scratch/453174058899/lean478-work/run-01/raw/lake_version.exit
cd /workspace/scratch/453174058899/lean478-work/run-01/worktree/tests/fixtures/lean_crosswalk/lean && lake build < /dev/null > /workspace/scratch/453174058899/lean478-work/run-01/raw/build_stdout.txt 2> /workspace/scratch/453174058899/lean478-work/run-01/raw/build_stderr.txt
printf '%s\n' "$?" > /workspace/scratch/453174058899/lean478-work/run-01/raw/build.exit
cd /workspace/scratch/453174058899/lean478-work/run-01/worktree/tests/fixtures/lean_crosswalk/lean && lake env lean CrosswalkProbe/Audit.lean < /dev/null > /workspace/scratch/453174058899/lean478-work/run-01/raw/audit_stdout.txt 2> /workspace/scratch/453174058899/lean478-work/run-01/raw/audit_stderr.txt
printf '%s\n' "$?" > /workspace/scratch/453174058899/lean478-work/run-01/raw/audit.exit
cd /workspace/scratch/453174058899/lean478-work/run-01/worktree/tests/fixtures/lean_crosswalk/lean && lake env lean --version < /dev/null > /workspace/scratch/453174058899/lean478-work/run-01/raw/lake_lean_version_stdout.txt 2> /workspace/scratch/453174058899/lean478-work/run-01/raw/lake_lean_version_stderr.txt
printf '%s\n' "$?" > /workspace/scratch/453174058899/lean478-work/run-01/raw/lake_lean_version.exit
cd /workspace/scratch/453174058899/lean478-work/run-01/worktree && python3 -I -B /workspace/scratch/453174058899/lean478-work/evidence/tools/read-audit.py /workspace/scratch/453174058899/lean478-work/run-01/worktree /workspace/scratch/453174058899/lean478-work/run-01/raw/audit.exit /workspace/scratch/453174058899/lean478-work/run-01/raw/audit_stdout.txt < /dev/null > /workspace/scratch/453174058899/lean478-work/run-01/raw/reader_stdout.txt 2> /workspace/scratch/453174058899/lean478-work/run-01/raw/reader_stderr.txt
printf '%s\n' "$?" > /workspace/scratch/453174058899/lean478-work/run-01/raw/reader.exit
cd /workspace/scratch/453174058899/lean478-work/run-01/worktree && sha256sum --check /workspace/scratch/453174058899/lean478-work/evidence/meta/sources.sha256 < /dev/null > /workspace/scratch/453174058899/lean478-work/run-01/raw/sources_after_stdout.txt 2> /workspace/scratch/453174058899/lean478-work/run-01/raw/sources_after_stderr.txt
printf '%s\n' "$?" > /workspace/scratch/453174058899/lean478-work/run-01/raw/sources_after.exit

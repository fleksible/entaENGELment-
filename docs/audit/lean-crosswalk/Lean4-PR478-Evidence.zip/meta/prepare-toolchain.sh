set -eu
umask 022
mkdir -p lean478-work/setup lean478-work/toolchain
ln -s /opt/codex/downloads/c0f8001f-272d-4c25-b393-573162bcda34/0e4f3a94-70b6-4584-912f-ca69beb92cab lean478-work/setup/lean-4.35.0-linux.tar.zst
cd lean478-work
printf '%s  %s\n' '7289597a44543246c9227b8cae501767e095ce17f6d448b95fc4a8dc97268f6d' 'setup/lean-4.35.0-linux.tar.zst' > evidence/meta/toolchain-archive.sha256
set +e
sha256sum --check evidence/meta/toolchain-archive.sha256 > evidence/raw/archive_check_stdout.txt 2> evidence/raw/archive_check_stderr.txt
check_rc=$?
printf '%s\n' "$check_rc" > evidence/raw/archive_check.exit
if [ "$check_rc" != 0 ]; then exit "$check_rc"; fi
tar --zstd -xf setup/lean-4.35.0-linux.tar.zst -C toolchain > evidence/raw/extract_stdout.txt 2> evidence/raw/extract_stderr.txt
extract_rc=$?
printf '%s\n' "$extract_rc" > evidence/raw/extract.exit
exit "$extract_rc"
